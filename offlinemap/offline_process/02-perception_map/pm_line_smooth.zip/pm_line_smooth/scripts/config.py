# -*- coding: UTF-8 -*-
import os
import sys
path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(path)
import re
import networkx as nx
from lib.database.pg import PostgreSQL
from lib.geometry.coord_trans import CoordTransformer


pg_map = PostgreSQL('postgres:root@localhost:5432/map')


long_center_value = 117.283
ctf = CoordTransformer(float(long_center_value))

srid = 32650

if pg_map is not None:
    df_link = pg_map.get('rns_link')
    df_lane = pg_map.get('mod_lane')
else:
    df_link = None
    df_lane = None

# df_junction = pg_map.get('rm_junctions')
# df_junction['id'] = df_junction['id'].astype(int)

# sql = f"select column_name from information_schema.columns where table_schema=\'public\' and table_name= 'rm_all_features'"
# data = pg_map.execute(sql,True)
# map_data_columns = [x[0] for x in data]
# map_data_columns.remove('utm')

map_range = [(117.280509949,39.753883362),(117.281341553,39.734710693),(117.273391724,39.685230255),(117.284439087,39.684730530),
             (117.266021729,39.664886475),(117.275733948,39.658943176),(117.296333313,39.681549072),(117.296745300,39.692096710),
             (117.285865784,39.693771362),(117.292144775,39.735797882),(117.290718079,39.753631592)]



