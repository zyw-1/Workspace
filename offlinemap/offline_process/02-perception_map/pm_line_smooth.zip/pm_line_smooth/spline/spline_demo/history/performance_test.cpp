#include <iostream>
#include <vector>
#include <chrono>
#include <Eigen/Dense>

using Vector4d = Eigen::Vector4d;
using Matrix4d = Eigen::Matrix4d;

// 定义一个直接使用三角函数进行变换的函数
void applyTransformDirectly(std::vector<Vector4d>& points, const Eigen::Matrix3d& rotation, const Eigen::Vector3d& translation) {
    double angle = acos((rotation.trace() - 1) / 2.0);
    Eigen::Vector3d axis = (angle == 0) ? Eigen::Vector3d(1, 0, 0) : 
        Eigen::Vector3d(rotation(2, 1) - rotation(1, 2),
                        rotation(0, 2) - rotation(2, 0),
                        rotation(1, 0) - rotation(0, 1)) / (2 * sin(angle));

    for (auto& point : points) {
        Eigen::Vector3d p = point.head<3>();
        // 旋转
        Eigen::Vector3d rotatedP = p * cos(angle) + axis.cross(p) * sin(angle) + axis * axis.dot(p) * (1 - cos(angle));
        // 平移
        point.head<3>() = rotatedP + translation;
    }
}

int main() {
    // 生成1000个随机点
    std::vector<Vector4d> points(1000);
    for (auto& point : points) {
        point = Vector4d::Random();
        point[3] = 1.0; // 设置齐次坐标
    }

    // 创建一个随机的旋转矩阵和平移向量
    Eigen::Matrix3d rotation = Eigen::Quaterniond::UnitRandom().toRotationMatrix();
    Eigen::Vector3d translation = Eigen::Vector3d::Random();

    // 创建齐次变换矩阵
    Matrix4d transform = Matrix4d::Identity();
    transform.block<3,3>(0,0) = rotation;
    transform.block<3,1>(0,3) = translation;

    // 使用循环逐个应用变换（矩阵乘法）
    std::vector<Vector4d> transformed_points_loop(points.size());
    auto start_loop = std::chrono::high_resolution_clock::now();
    for (size_t i = 0; i < points.size(); ++i) {
        transformed_points_loop[i] = transform * points[i];
    }
    auto end_loop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration_loop = end_loop - start_loop;
    std::cout << "Loop with matrix multiplication took: " << duration_loop.count() << " milliseconds." << std::endl;

    // 使用循环直接应用变换（三角函数）
    std::vector<Vector4d> transformed_points_direct(points);
    auto start_direct = std::chrono::high_resolution_clock::now();
    applyTransformDirectly(transformed_points_direct, rotation, translation);
    auto end_direct = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration_direct = end_direct - start_direct;
    std::cout << "Direct method using trigonometric functions took: " << duration_direct.count() << " milliseconds." << std::endl;

    return 0;
}
