//
// Created by faye on 6/12/24.
//
#include <Eigen/Sparse>
#include <iostream>

int main() {
    // 定义类型
    typedef Eigen::SparseMatrix<double> SparseMatrix;
    typedef Eigen::Triplet<double> Triplet;

    // 创建一个大的稀疏矩阵 (5x5)
    SparseMatrix largeMatrix(5, 5);

    // 用一些值填充大的稀疏矩阵
    std::vector<Triplet> tripletList;
    tripletList.push_back(Triplet(0, 0, 1.0));
    tripletList.push_back(Triplet(1, 1, 2.0));
    tripletList.push_back(Triplet(2, 2, 3.0));
    tripletList.push_back(Triplet(3, 3, 4.0));
    tripletList.push_back(Triplet(4, 4, 5.0));
    largeMatrix.setFromTriplets(tripletList.begin(), tripletList.end());

    // 创建一个小的稀疏矩阵 (2x2)
    SparseMatrix smallMatrix(2, 2);
    std::vector<Triplet> smallTripletList;
    smallTripletList.push_back(Triplet(0, 0, 7.0));
    smallTripletList.push_back(Triplet(0, 1, 8.0));
    smallTripletList.push_back(Triplet(1, 0, 9.0));
    smallTripletList.push_back(Triplet(1, 1, 10.0));
    smallMatrix.setFromTriplets(smallTripletList.begin(), smallTripletList.end());

    // 分块赋值：将 smallMatrix 赋值给 largeMatrix 的 (1,1) 开始的 2x2 块
    // largeMatrix.block(1, 1, 2, 2) = smallMatrix;

    // 输出结果矩阵
    std::cout << "Large matrix after block assignment:\n" << Eigen::MatrixXd(largeMatrix) << std::endl;

    return 0;
}
