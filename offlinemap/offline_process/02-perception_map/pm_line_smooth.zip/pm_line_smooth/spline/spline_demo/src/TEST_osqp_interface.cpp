//
// Created by faye on 24-8-25.
//
//
#include <iostream>
#include "osqp_interface.h"

int main() {
    // 构造QpSolver对象，指定变量和约束的维度
    QpSolver solver;
    solver.setDataDiemension(2,2);

    // 初始化矩阵和向量
    Eigen::SparseMatrix<double> hessian(2, 2);
    Eigen::VectorXd gradient(2);
    Eigen::SparseMatrix<double> linear_matrix(2, 2);
    Eigen::VectorXd lower_bound(2);
    Eigen::VectorXd upper_bound(2);

    // 设置矩阵和向量的值e
    hessian.insert(0, 0) = 2.0;
    hessian.insert(1, 1) = 2.0;
    gradient << -2, -2;
    linear_matrix.insert(0, 0) = 1.0;
    linear_matrix.insert(1, 1) = 1.0;
    lower_bound << 1, 1;
    upper_bound << 1.5, 1.5;

    // 使用QpSolver类设置问题
    solver.setHessianMatrix(hessian);
    solver.setGradient(gradient);
    solver.setLinearConstraintsMatrix(linear_matrix);
    solver.setLowerBound(lower_bound);
    solver.setUpperBound(upper_bound);

    // 初始化并求解
    solver.initializeSolver();
    Eigen::VectorXd QPSolution = solver.Solve();

    // 输出结果
    std::cout << "QPSolution:" << std::endl << QPSolution << std::endl;

    return 0;
}
