//
// Created by faye on 8/22/24.
//
#include <cmath>
#include <vector>

#include "utils_math.h"

constexpr double kDistEpsilonSquare = 0.0009; // within 3cm, regarded as duplicate points
constexpr double kMathEpsilon = 1e-6;

double squaredSum(const double& x, const double& y) {
  return x * x + y * y;
}

bool RemoveDuplicatePoints(std::vector<Point>* points) {
  auto num_of_points =  points->size();

  size_t count = 0;
  for(auto i = 0; i < num_of_points; i++) {

    if(count == 0 || squaredSum((*points)[i].x-(*points)[count-1].x, (*points)[i].y-(*points)[count-1].y) >kDistEpsilonSquare) {
      (*points)[count++] = (*points)[i];
    }
  }
  points->resize(count);
  return true;
}

double NormalizeAngle(const double angle) {
  double a = std::fmod(angle + M_PI, 2.0 * M_PI);
  if (a < 0.0) {
    a += (2.0 * M_PI);
  }
  return a - M_PI;
}

double AngleDiff(const double from, const double to) {
  return NormalizeAngle(to - from);
}


double slerp(const double a0, const double t0, const double a1, const double t1,
             const double t) {
  if (std::abs(t1 - t0) <= kMathEpsilon) {
    return NormalizeAngle(a0);
  }
  const double a0_n = NormalizeAngle(a0);
  const double a1_n = NormalizeAngle(a1);
  double d = a1_n - a0_n;
  if (d > M_PI) {
    d = d - 2 * M_PI;
  } else if (d < -M_PI) {
    d = d + 2 * M_PI;
  }

  const double r = (t - t0) / (t1 - t0);
  const double a = a0_n + d * r;
  return NormalizeAngle(a);
}

double lerp(const double &x0, const double t0, const double &x1, const double t1, const double t) {
  if (std::abs(t1 - t0) <= 1.0e-6) {
    return x0;
  }
  const double r = (t - t0) / (t1 - t0);
  const double x = x0 + r * (x1 - x0);

  return x;
}


bool ComputePathProfile(
    const std::vector<Point>& xy_points,
    std::vector<double>* headings, std::vector<double>* accumulated_s,
    std::vector<double>* kappas, std::vector<double>* dkappas) {

  // headings->clear();
  // kappas->clear();
  // dkappas->clear();

  if (xy_points.size() < 2) {
    return false;
  }
  std::vector<double> dxs;
  std::vector<double> dys;
  std::vector<double> y_over_s_first_derivatives;
  std::vector<double> x_over_s_first_derivatives;
  std::vector<double> y_over_s_second_derivatives;
  std::vector<double> x_over_s_second_derivatives;

  // Get finite difference approximated dx and dy for heading and kappa
  // calculation
  std::size_t points_size = xy_points.size();


  for (std::size_t i = 0; i < points_size; ++i) {
    double x_delta = 0.0;
    double y_delta = 0.0;
    if (i == 0) {
      x_delta = (xy_points[i + 1].x - xy_points[i].x);
      y_delta = (xy_points[i + 1].y - xy_points[i].y);
    } else if (i == points_size - 1) {
      x_delta = (xy_points[i].x - xy_points[i - 1].x);
      y_delta = (xy_points[i].y - xy_points[i - 1].y);
    } else {
      x_delta = 0.5 * (xy_points[i + 1].x - xy_points[i - 1].x);
      y_delta = 0.5 * (xy_points[i + 1].y - xy_points[i - 1].y);
    }
    dxs.push_back(x_delta);
    dys.push_back(y_delta);
  }

  // Heading calculation
  for (std::size_t i = 0; i < points_size; ++i) {
    headings->push_back(std::atan2(dys[i], dxs[i]));
  }

  // Get linear interpolated s for dkappa calculation
  double distance = 0.0;
  accumulated_s->push_back(distance);
  double fx = xy_points[0].x;
  double fy = xy_points[0].y;
  double nx = 0.0;
  double ny = 0.0;
  for (std::size_t i = 1; i < points_size; ++i) {
    nx = xy_points[i].x;
    ny = xy_points[i].y;
    double end_segment_s =
        std::sqrt((fx - nx) * (fx - nx) + (fy - ny) * (fy - ny));
    accumulated_s->push_back(end_segment_s + distance);
    distance += end_segment_s;
    fx = nx;
    fy = ny;
  }

  // Get finite difference approximated first derivative of y and x respective
  // to s for kappa calculation
  for (std::size_t i = 0; i < points_size; ++i) {
    double xds = 0.0;
    double yds = 0.0;
    if (i == 0) {
      xds = (xy_points[i + 1].x - xy_points[i].x) /
            (accumulated_s->at(i + 1) - accumulated_s->at(i));
      yds = (xy_points[i + 1].y - xy_points[i].y) /
            (accumulated_s->at(i + 1) - accumulated_s->at(i));
    } else if (i == points_size - 1) {
      xds = (xy_points[i].x - xy_points[i - 1].x) /
            (accumulated_s->at(i) - accumulated_s->at(i - 1));
      yds = (xy_points[i].y - xy_points[i - 1].y) /
            (accumulated_s->at(i) - accumulated_s->at(i - 1));
    } else {
      xds = (xy_points[i + 1].x - xy_points[i - 1].x) /
            (accumulated_s->at(i + 1) - accumulated_s->at(i - 1));
      yds = (xy_points[i + 1].y - xy_points[i - 1].y) /
            (accumulated_s->at(i + 1) - accumulated_s->at(i - 1));
    }
    x_over_s_first_derivatives.push_back(xds);
    y_over_s_first_derivatives.push_back(yds);
  }

  // Get finite difference approximated second derivative of y and x respective
  // to s for kappa calculation
  for (std::size_t i = 0; i < points_size; ++i) {
    double xdds = 0.0;
    double ydds = 0.0;
    if (i == 0) {
      xdds =
          (x_over_s_first_derivatives[i + 1] - x_over_s_first_derivatives[i]) /
          (accumulated_s->at(i + 1) - accumulated_s->at(i));
      ydds =
          (y_over_s_first_derivatives[i + 1] - y_over_s_first_derivatives[i]) /
          (accumulated_s->at(i + 1) - accumulated_s->at(i));
    } else if (i == points_size - 1) {
      xdds =
          (x_over_s_first_derivatives[i] - x_over_s_first_derivatives[i - 1]) /
          (accumulated_s->at(i) - accumulated_s->at(i - 1));
      ydds =
          (y_over_s_first_derivatives[i] - y_over_s_first_derivatives[i - 1]) /
          (accumulated_s->at(i) - accumulated_s->at(i - 1));
    } else {
      xdds = (x_over_s_first_derivatives[i + 1] -
              x_over_s_first_derivatives[i - 1]) /
             (accumulated_s->at(i + 1) - accumulated_s->at(i - 1));
      ydds = (y_over_s_first_derivatives[i + 1] -
              y_over_s_first_derivatives[i - 1]) /
             (accumulated_s->at(i + 1) - accumulated_s->at(i - 1));
    }
    x_over_s_second_derivatives.push_back(xdds);
    y_over_s_second_derivatives.push_back(ydds);
  }

  for (std::size_t i = 0; i < points_size; ++i) {
    double xds = x_over_s_first_derivatives[i];
    double yds = y_over_s_first_derivatives[i];
    double xdds = x_over_s_second_derivatives[i];
    double ydds = y_over_s_second_derivatives[i];
    double kappa =
        (xds * ydds - yds * xdds) /
        (std::sqrt(xds * xds + yds * yds) * (xds * xds + yds * yds) + 1e-6);
    kappas->push_back(kappa);
  }

  // Dkappa calculation
  for (std::size_t i = 0; i < points_size; ++i) {
    double dkappa = 0.0;
    if (i == 0) {
      dkappa = (kappas->at(i + 1) - kappas->at(i)) /
               (accumulated_s->at(i + 1) - accumulated_s->at(i));
    } else if (i == points_size - 1) {
      dkappa = (kappas->at(i) - kappas->at(i - 1)) /
               (accumulated_s->at(i) - accumulated_s->at(i - 1));
    } else {
      dkappa = (kappas->at(i + 1) - kappas->at(i - 1)) /
               (accumulated_s->at(i + 1) - accumulated_s->at(i - 1));
    }
    dkappas->push_back(dkappa);
  }
  return true;
}


double GaussLegendreIntegrate4(const std::function<double(double)>& fx, double lower_bound, double upper_bound) {
  GaussLegendre4 gl4;

  double t = (upper_bound - lower_bound) / 2.0;
  double m = (upper_bound + lower_bound) / 2.0;

  double result = 0.0;
  for (size_t i = 0; i < 4; ++i) {
    result += gl4.weights[i] * fx(t * gl4.roots[i] + m);
  }

  result *= (upper_bound - lower_bound) / 2.0;  // (b-a)/2.0;
  return result;
}

double PolyValue5th(const std::vector<double>& poly, double t) {
  double res = 0.0;
  for(auto i =5; i>=0; --i) {
    res = res * t + poly[i];
  }
  return res;
}

double PolyValue5thDerivate(const std::vector<double>& poly, double t) {
  double res = 0.0;
  for(auto i = 5; i >=1; --i) {
    res = res * t + poly[i] * i;
    std::cout<< res<<std::endl;
  }
  return res;
}

std::tuple<double, double, double, double, double> GetSplinePointInfo(const std::vector<double>& coef_x, const std::vector<double>& coef_y, double t) {
  // 预计算 t 的不同次方
  double t2 = t * t;
  double t3 = t2 * t;
  double t4 = t3 * t;
  double t5 = t4 * t;

  // 计算 0 阶函数值 x(t) 和 y(t)
  double x = coef_x[0] + coef_x[1] * t + coef_x[2] * t2 + coef_x[3] * t3 + coef_x[4] * t4 + coef_x[5] * t5;
  double y = coef_y[0] + coef_y[1] * t + coef_y[2] * t2 + coef_y[3] * t3 + coef_y[4] * t4;
  // 计算一阶导数
  double dx = coef_x[1] + 2 * coef_x[2] * t + 3 * coef_x[3] * t2 + 4 * coef_x[4] * t3 + 5 * coef_x[5] * t4;
  double dy = coef_y[1] + 2 * coef_y[2] * t + 3 * coef_y[3] * t2 + 4 * coef_y[4] * t3;
  // 计算二阶导数
  double ddx = 2 * coef_x[2] + 6 * coef_x[3] * t + 12 * coef_x[4] * t2 + 20 * coef_x[5] * t3;
  double ddy = 2 * coef_y[2] + 6 * coef_y[3] * t + 12 * coef_y[4] * t2;
  // 计算曲率 kappa
  double num_kappa = dx * ddy - dy * ddx;
  double den_kappa = std::pow(dx * dx + dy * dy, 3.0 / 2.0);
  double kappa = num_kappa / den_kappa;
  // 计算三阶导数
  double dddx = 6 * coef_x[3] + 24 * coef_x[4] * t + 60 * coef_x[5] * t2;
  double dddy = 6 * coef_y[3] + 24 * coef_y[4] * t;
  // 计算 kappa 的导数 dkappa
  double num_dkappa = -3 * (num_kappa * (dx * dddy - dy * dddx) - ddy * dddx * (dx * dx + dy * dy));
  double den_dkappa = std::pow(dx * dx + dy * dy, 5.0 / 2.0);
  double dkappa = num_dkappa / den_dkappa;
  // 计算 heading
  double heading = std::atan2(dy, dx);
  return std::make_tuple(x, y, kappa, dkappa, heading);
}