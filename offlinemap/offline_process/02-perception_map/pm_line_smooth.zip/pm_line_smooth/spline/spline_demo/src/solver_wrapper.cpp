#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>

#include <memory>
#include "algorithm.h"

namespace py = pybind11;

class Solver {
public:
    Solver() : algorithm_instance(std::make_shared<Algorithm>()) {
    }

    // 接收 numpy 数组和两个额外的 double 参数
    void init(py::array_t<double> raw_x_np, py::array_t<double> raw_y_np, double heading_start, double heading_end) {
        auto raw_x_buf = raw_x_np.request(); // 获取 numpy 数组信息
        auto raw_y_buf = raw_y_np.request();

        if (raw_x_buf.shape[0] != raw_y_buf.shape[0]) {
            throw std::runtime_error("raw_x and raw_y must have the same size");
        }

        // 转换 numpy 数组为 std::vector<double>
        std::vector<double> raw_x(static_cast<double *>(raw_x_buf.ptr), static_cast<double *>(raw_x_buf.ptr) + raw_x_buf.shape[0]);
        std::vector<double> raw_y(static_cast<double *>(raw_y_buf.ptr), static_cast<double *>(raw_y_buf.ptr) + raw_y_buf.shape[0]);

        // 使用新的参数调用初始化算法
        algorithm_instance->initialize(raw_x, raw_y, heading_start, heading_end);
    }

    // 获取结果并返回 numpy 2D 数组
    py::array_t<double> get_solution() {
        std::vector<std::vector<double>> results = algorithm_instance->get_solution();

        // 将 std::vector<std::vector<double>> 转换为 2D numpy array
        size_t rows = results.size();
        size_t cols = results[0].size();

        // 创建一个空的 2D numpy array
        py::array_t<double> result_np({rows, cols});

        auto result_np_buf = result_np.request();
        double *ptr = static_cast<double *>(result_np_buf.ptr);

        // 将结果拷贝到 numpy 数组中
        for (size_t i = 0; i < rows; ++i) {
            for (size_t j = 0; j < cols; ++j) {
                ptr[i * cols + j] = results[i][j];
            }
        }

        return result_np;
    }

private:
    std::shared_ptr<Algorithm> algorithm_instance;
};

// Pybind11 模块定义
PYBIND11_MODULE(pybind_solver, m) {
    py::class_<Solver>(m, "Solver")
            .def(py::init<>())
            .def("init", &Solver::init, "Initialize with two numpy arrays and two doubles",
                 py::arg("raw_x"), py::arg("raw_y"), py::arg("heading_start"), py::arg("heading_end"))
            .def("get_solution", &Solver::get_solution, "Get solution as 2D numpy array");
}
