//
// Created by faye on 8/22/24.
//
#include <cmath>
#include <iostream>
#include <vector>

#include "OsqpEigen/OsqpEigen.h"
#include "base.h"
#include "spline_solver.h"

#include <numeric>
#include <utils_math.h>

using Eigen::MatrixXd;
using Eigen::VectorXd;

SplineSolver::SplineSolver(const std::vector<ReferencePoint> &anchor) : anchor_(anchor) {
  // 警告提示
  if (anchor.size() < 3) {
    throw std::runtime_error("Failed to set linear constraints matrix");
  }

  raw_length_ = anchor_.back().s - anchor_.front().s;

  // 四舍五入计算段数
  num_of_anchor_ = static_cast<int>(anchor_.size());
  double quotient = raw_length_ / weights_.knot_interval;
  num_of_splines_ = static_cast<int>((quotient - std::floor(quotient)) > 1.0e-4 ? std::ceil(quotient) : std::floor(quotient));
  num_of_params_ = num_of_splines_ * 2 * (spline_order + 1);

  knot_sclar_ = raw_length_ / num_of_splines_;

  // 相对坐标计算，最后返回插值平滑结果之前需要还原原始坐标。
  ref_x = anchor_.front().x;
  ref_y = anchor_.front().y;
  ref_s = anchor_.front().s;

  for (auto &p: anchor_) {
    p.x = p.x - ref_x;
    p.y = p.y - ref_y;
    p.s = p.s - ref_s;
  }

  // 设置 t_knot
  knot_s_.resize(num_of_splines_ + 1);
  for (auto i = 0; i < num_of_splines_ + 1; ++i) {
    knot_s_[i] = knot_sclar_ * i;
  }

  // 分段计算每个anchor point位于哪个segment，相对的t_offset是多少
  anchor_t_offset_.resize(num_of_anchor_);
  anchor_knot_index_.resize(num_of_anchor_);

  for (auto i = 0; i < num_of_anchor_; ++i) {
    auto res = FindIndex(knot_s_, anchor_[i].s);
    // int index = static_cast<int>(anchor_[i].s / knot_sclar_);
    // anchor_knot_index_[i] = index;
    // anchor_t_offset_[i] = (anchor_[i].s - knot_sclar_ * index)/knot_sclar_;
    anchor_knot_index_[i] = res.first;
    anchor_t_offset_[i] = res.second / knot_sclar_;
  }

  // { // debug 打印
  //   fmt::print("===========\n");
  //   fmt::print("打印所有anchor points 的分段knot信息\n");
  //   for (auto i = 0; i < num_of_anchor_; ++i)
  //   {
  //     fmt::print("index: {}, s: {:.4f}, knot_index: {}, t_offset: {:.4f}\n",
  //                i, anchor_[i].s, anchor_knot_index_[i], anchor_t_offset_[i]);
  //   }
  // }

  // FIX 2024-11-03 准备起点终点的pos+heading信息
  s_x = 0.0;
  s_y = 0.0;
  s_head = anchor_.front().heading;

  e_x = anchor_.back().x;
  e_y = anchor_.back().y;
  e_head = anchor_.back().heading;
  e_t_offset = anchor_t_offset_.back();

  if (!SetMatrixSize()) {
    std::cerr << "设置 QP Kernel 和 约束的维度 失败" << std::endl;
  } else {
    std::cout << "设置 QP Kernel 和 约束的维度 成功" << std::endl;
  }

  // csv_writer_.setFilenameWithTimestamp();
}

bool SplineSolver::SetMatrixSize() {
  // TODO 增加入参：输入的尺寸，而不是直接从类成员中读取

  // 设置 kernel的大小
  kernel_.setZero(num_of_params_, num_of_params_);

  // 约束是纵向拼接，有3个部分
  // 连接knot处 0/1/2/3 order 平滑
  // 起点终点 的heading方向与拟合点一致
  // 所有anchor的 横纵向bound的上限界限

  num_constraint_smooth_ = 2 * 4 * (num_of_splines_ - 1);
  num_constraint_bound_ = 2 * num_of_anchor_;
  // num_constraint_angle_ = 2 * 1;
  // num_constraint_ = num_constraint_smooth_ + num_constraint_angle_ + num_constraint_bound_;


  // FIX 2024-11-03 起终点的方向+位置
  // 2* (1+1+1+1)
  // x位置+y位置+方向点乘+方向叉乘
  num_constraint_startend_ = 8;
  num_constraint_ = num_constraint_smooth_ + num_constraint_bound_ + num_constraint_startend_;
  constraint_startend_.setZero(num_constraint_startend_,num_of_params_);
  lb_startend_.setZero(num_constraint_startend_, 1);
  ub_startend_.setZero(num_constraint_startend_, 1);


  // 设置constraint 矩阵的维度
  constraint_.setZero(num_constraint_, num_of_params_);
  // constraint_angle_.setZero(num_constraint_angle_, num_of_params_);
  constraint_smooth_.setZero(num_constraint_smooth_, num_of_params_);
  constraint_bound_.setZero(num_constraint_bound_, num_of_params_);

  // 设置boundary 向量的维度
  // lb_angle_.setZero(num_constraint_angle_, 1);
  // ub_angle_.setZero(num_constraint_angle_, 1);
  lb_smooth_.setZero(num_constraint_smooth_, 1);
  ub_smooth_.setZero(num_constraint_smooth_, 1);
  lb_bound_.setZero(num_constraint_bound_, 1);
  ub_bound_.setZero(num_constraint_bound_, 1);
  upper_bound_.setZero(num_constraint_, 1);
  lower_bound_.setZero(num_constraint_, 1);

  return true;
}

std::pair<size_t, double> SplineSolver::FindIndex(const std::vector<double> &knot_s, double s) {
  if (s + kEpsilon < knot_s.front() || s > knot_s.back() + kEpsilon) {
    std::cerr << s << "is out of range" << std::endl;
    std::abort();
  }
  if (s + kEpsilon < knot_s.front() || s > knot_s.back() + kEpsilon) {
    std::cerr << s << "is out of range" << std::endl;
    std::abort();
  }

  auto it = std::upper_bound(knot_s.begin(), knot_s.end(), s);

  auto index = std::distance(knot_s.begin(), it) - 1;
  if (index == knot_s.size() - 1) { index = index - 1; };

  double offset = s - knot_s[index];

  return {index, offset};
}

bool SplineSolver::AddSecondDerivativeKernel(const double weight) {
  /* 积分后的二阶导数kernel t=[0,1]积分得来
{
    {0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0},
    {0, 0, 4, 6, 8, 10},
    {0, 0, 6, 12, 18, 24},
    {0, 0, 8, 18, 144/5, 40},
    {0, 0, 10, 24, 40, 400/7}
}
*/
  MatrixXd matrix = MatrixXd::Zero(6, 6);
  // 手动设置矩阵的特定值
  matrix(2, 2) = 4;
  matrix(2, 3) = 6;
  matrix(2, 4) = 8;
  matrix(2, 5) = 10;

  matrix(3, 2) = 6;
  matrix(3, 3) = 12;
  matrix(3, 4) = 18;
  matrix(3, 5) = 24;

  matrix(4, 2) = 8;
  matrix(4, 3) = 18;
  matrix(4, 4) = 144.0 / 5.0; // 28.8
  matrix(4, 5) = 40;

  matrix(5, 2) = 10;
  matrix(5, 3) = 24;
  matrix(5, 4) = 40;
  matrix(5, 5) = 400.0 / 7.0;

  matrix *= weight;
  // 直接用block赋值，xy都有，所以是2倍大小
  for (auto i = 0; i < 2 * num_of_splines_; i++) {
    kernel_.block<6, 6>(6 * i, 6 * i) += matrix;
  }
  return true;
}

bool SplineSolver::AddThridDerivativeKernel(const double weight) {
  /* 三阶倒数kernel的积分 从t=[0,1]积分
{
    {0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0},
    {0, 0, 0, 36, 72, 120},
    {0, 0, 0, 72, 192, 360},
    {0, 0, 0, 120, 360, 720}
}
*/
  MatrixXd matrix = MatrixXd::Zero(6, 6);
  // 逐元素赋值非零项
  matrix(3, 3) = 36;
  matrix(3, 4) = 72;
  matrix(3, 5) = 120;

  matrix(4, 3) = 72;
  matrix(4, 4) = 192;
  matrix(4, 5) = 360;

  matrix(5, 3) = 120;
  matrix(5, 4) = 360;
  matrix(5, 5) = 720;
  matrix *= weight;

  for (auto i = 0; i < 2 * num_of_splines_; i++) {
    kernel_.block<6, 6>(6 * i, 6 * i) += matrix;
  }
  return true;
}

bool SplineSolver::AddRegularizationKernel(const double weight) {
  kernel_.diagonal().array() += weight;
  return true;
}

bool SplineSolver::AddStartEndPointConstraint(double s_x, double s_y, double s_head, double e_x, double e_y, double e_head, double e_t_offset){
  // 方向约束+ 位置约束 
  // 暂时不约束2阶 3阶，因为起点终点处本身离散点计算的曲率、曲率变化率就不会很准

  const double kEpsilon_pos = 1.0e-6;
  const double kEpsilon_angle = 1.0e-3;
  int index_offset = 6 * (num_of_splines_);
  // ===========
  // start point
  // x位置+y位置+方向点乘+方向叉乘
  // 0阶: [1, 1*t, 1*t^2, 1*t^3, 1*t^4, 1*t^5] 对应 t=0.0时 [1,0,0,0,0,0]
  // 1阶: [0, 1, 2*t, 3*t^2, 4*t^3, 5*t^4] 对应 t=0.0时 [0,1,0,0,0,0]
  // ===========
  // x位置
  lb_startend_(0, 0) = s_x - kEpsilon_pos;
  ub_startend_(0, 0) = s_x + kEpsilon_pos;
  constraint_startend_(0, 0) = 1.0;
  // y位置
  lb_startend_(1, 0) = s_y - kEpsilon_pos;
  ub_startend_(1, 0) = s_y + kEpsilon_pos;
  constraint_startend_(1, 0 + index_offset) = 1.0;
  // 方向叉乘 0.0<= dx*sin(theta) -dy*cos(theta)<=0.0
  lb_startend_(2, 0) = - kEpsilon_angle;
  ub_startend_(2, 0) = + kEpsilon_angle;
  constraint_startend_(2, 1) = 1.0 * std::sin(s_head);;
  constraint_startend_(2, 1+index_offset) = -1.0 * std::cos(s_head);
  // 方向点乘 0.0<= dx*cos(theta) + dy*sin(theta)<= osqp::infinity
  lb_startend_(3, 0) = - kEpsilon_angle;
  ub_startend_(3, 0) = OsqpEigen::INFTY;
  constraint_startend_(3, 1) = 1.0 * std::cos(s_head);
  constraint_startend_(3, 1+index_offset) = 1.0 * std::sin(s_head);

  // ===========
  // end point
  // x位置+y位置+方向点乘+方向叉乘
  // 0阶: [1, 1*t, 1*t^2, 1*t^3, 1*t^4, 1*t^5] 对应 t=e_t_offset时 [1,e_t,e_t^2,e_t^3,e_t^4,e_t^5]
  // 1阶: [0, 1, 2*t, 3*t^2, 4*t^3, 5*t^4] 对应 t=e_t_offset时 [0, 1, 2*e_t, 3*e_t^2, 4*e_t^3, 5*e_t^4]
  // ===========
  // t_poly
  Eigen::MatrixXd t_poly = Eigen::MatrixXd::Zero(1, 6);
  t_poly(0, 0) = 1.0;
  for (auto i = 1; i < 6; i++) {
    t_poly(0, i) = t_poly(0, i - 1) * e_t_offset;
  }
  Eigen::MatrixXd t_poly_1 = Eigen::MatrixXd::Zero(1, 6);
  t_poly_1(0, 0) = 0.0;
  for (auto j = 1; j < 6; j++) {
    t_poly_1(0, j) = j * t_poly(0, j-1);
  }
  // x位置
  lb_startend_(4, 0) = e_x - kEpsilon_pos;
  ub_startend_(4, 0) = e_x + kEpsilon_pos;
  constraint_startend_.block<1, 6>(4, index_offset-6) = t_poly;
  // y位置
  lb_startend_(5, 0) = e_y - kEpsilon_pos;
  ub_startend_(5, 0) = e_y + kEpsilon_pos;
  constraint_startend_.block<1, 6>(5, 2 * index_offset - 6) = t_poly;
  // 方向叉乘 0.0<= dx*sin(theta) -dy*cos(theta)<=0.0
  lb_startend_(6, 0) = - kEpsilon_angle;
  ub_startend_(6, 0) = + kEpsilon_angle;
  constraint_startend_.block<1, 6>(6, index_offset-6) = std::sin(e_head) * t_poly_1;
  constraint_startend_.block<1, 6>(6, 2 * index_offset - 6) = -1.0 * std::cos(e_head) * t_poly_1;
  // 方向点乘 0.0<= dx*cos(theta) + dy*sin(theta)<= osqp::infinity
  lb_startend_(7, 0) = - kEpsilon_angle;
  ub_startend_(7, 0) = OsqpEigen::INFTY;
  constraint_startend_.block<1, 6>(7, index_offset-6) = std::cos(e_head) * t_poly_1;
  constraint_startend_.block<1, 6>(7, 2 * index_offset - 6) = 1.0 * std::sin(e_head) * t_poly_1;

  // 完整的约束就是8项
  return true;
}

bool SplineSolver::AddPointDirectionConstraint(const double raw_heading) {
  // 方向约束 ： 大小可以不相同，但是方向一致
  // 方案1  dy - dx*tan(heading) <= Epsilon && dx - dy*tan(heading) >= -Epsilon

  // 方案2  先把dx' dy' 投影到 heading轴上，
  // 轴向偏差小于Epsilon（本质就是叉乘求垂向投影，heading对应的向量是单位向量）;
  // 方案2  向量(dx',dy')与i 向量 (cos(heading),sin(heading))的内积大于0

  // constraint_angle_ 大小 (2, num_of_params_)
  // [0, 1, 2*t, 3*t^2, 4*t^3, 5*t^4] 对应 t=0.0时
  // [0,1,0,0,0,0]
  int index_offset = 6 * (num_of_splines_);

  // 0.0<= dx*sin(theta) -dy*cos(theta)<=0.0
  lb_angle_(0, 0) = -kEpsilon;
  ub_angle_(0, 0) = kEpsilon;
  constraint_angle_(0, 1) = 1.0 * std::sin(raw_heading);
  constraint_angle_(0, 1 + index_offset) = -1.0 * std::cos(raw_heading);

  // 0.0<= dx*cos(theta) + dy*sin(theta)<= osqp::infinity
  lb_angle_(1, 0) = -kEpsilon;
  ub_angle_(1, 0) = OsqpEigen::INFTY;
  constraint_angle_(1, 1) = 1.0 * std::cos(raw_heading);
  constraint_angle_(1, 1 + index_offset) = 1.0 * std::sin(raw_heading);

  return true;
}

bool SplineSolver::AddKnotSmoothConstraint() {
  // connect knot point smoothing
  // TODO 等式约束使用epsilon
  // Constraint_smooth : [8, nums_of_params]
  // lb&ub for smooth : [8, 1]

  const double kEpsilon = 1.0e-8;

  // prev = next 0/1/2/3 order
  // 函数数值 [1,t^2,t^3,t^4,t^5]
  // 一阶导数 [0, 1, 2*t, 3*t^2, 4*t^3, 5*t^4]
  // 二阶导数 [0, 0, 2, 6*t, 12*t^2, 20*t^3]
  // 三阶导数 [0, 0, 0, 6, 24*t, 60*t^2]
  auto mat_pre = Eigen::MatrixXd(4, 6);
  auto mat_next = Eigen::MatrixXd(4, 6);

  mat_pre << 1, 1, 1, 1, 1, 1, 0, 1, 2, 3, 4, 5, 0, 0, 2, 6, 12, 20, 0, 0, 0, 6,
      24, 60;

  mat_next << 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 6,
      0, 0;

  int col_offset = 6 * num_of_splines_;
  int row_offset = 4 * (num_of_splines_ - 1);
  for (auto i = 0; i < num_of_splines_ - 1; i++) {
    // ────────────────────────────────────────────────────────────────
    // (╯°□°）╯︵ ┻━┻          // 掀桌子！  矩阵整体形状
    // ────────────────────────────────────────────────────────────────
    // 4*i+0: -b <= AX <= b
    // 4*i+1: -b <= AdX <= b
    // 4*i+2: -b <= AddX <= b
    // 4*i+3: -b <= AdddX <= b
    // 4*i+0+ offset: -b <= AY <= b
    // 4*i+1+ offset: -b <= AdY <= b
    // 4*i+2+ offset: -b <= AddY <= b
    // 4*i+3+ offset: -b <= AdddY <= b

    // ────────────────────────────────────────────────────────────────
    // (╯°□°）╯︵ ┻━┻          // 掀桌子！ x 的系数部分
    // ────────────────────────────────────────────────────────────────
    // 函数数值
    // 0: -b <= AX <= b
    constraint_smooth_.block<1, 6>(4 * i + 0, 6 * i) += mat_pre.block<1, 6>(0, 0);
    constraint_smooth_.block<1, 6>(4 * i + 0, 6 * i + 6) -= mat_next.block<1, 6>(0, 0);
    lb_smooth_(4 * i + 0, 0) = -kEpsilon; // kEpsilon
    ub_smooth_(4 * i + 0, 0) = kEpsilon;

    // 一阶导
    // 1: -b <= AdX <= b
    constraint_smooth_.block<1, 6>(4 * i + 1, 6 * i) += mat_pre.block<1, 6>(1, 0);
    constraint_smooth_.block<1, 6>(4 * i + 1, 6 * i + 6) -= mat_next.block<1, 6>(1, 0);
    lb_smooth_(4 * i + 1, 0) = -kEpsilon; // kEpsilon
    ub_smooth_(4 * i + 1, 0) = kEpsilon;

    // 二阶导
    // 2: -b <= AddX <= b
    constraint_smooth_.block<1, 6>(4 * i + 2, 6 * i) += mat_pre.block<1, 6>(2, 0);
    constraint_smooth_.block<1, 6>(4 * i + 2, 6 * i + 6) -= mat_next.block<1, 6>(2, 0);
    lb_smooth_(4 * i + 2, 0) = -kEpsilon; // kEpsilon
    ub_smooth_(4 * i + 2, 0) = kEpsilon;

    // 三阶导
    // 3: -b <= AdddX <= b
    constraint_smooth_.block<1, 6>(4 * i + 3, 6 * i) += mat_pre.block<1, 6>(3, 0);
    constraint_smooth_.block<1, 6>(4 * i + 3, 6 * i + 6) -= mat_next.block<1, 6>(3, 0);
    lb_smooth_(4 * i + 3, 0) = -kEpsilon; // kEpsilon
    ub_smooth_(4 * i + 3, 0) = kEpsilon;

    // ────────────────────────────────────────────────────────────────
    // (╯°□°）╯︵ ┻━┻          // 掀桌子！y 的系数部分
    // ────────────────────────────────────────────────────────────────

    // 函数数值
    // 4: -b <= AY <= b
    constraint_smooth_.block<1, 6>(4 * i + 0 + row_offset, 6 * i + col_offset) += mat_pre.block<1, 6>(0, 0);
    constraint_smooth_.block<1, 6>(4 * i + 0 + row_offset, 6 * i + 6 + col_offset) -= mat_next.block<1, 6>(0, 0);
    lb_smooth_(4 * i + 0 + row_offset, 0) = -kEpsilon; // kEpsilon
    ub_smooth_(4 * i + 0 + row_offset, 0) = kEpsilon;
    // 一阶导
    // 5: -b <= AdY <= b
    constraint_smooth_.block<1, 6>(4 * i + 1 + row_offset, 6 * i + col_offset) += mat_pre.block<1, 6>(1, 0);
    constraint_smooth_.block<1, 6>(4 * i + 1 + row_offset, 6 * i + 6 + col_offset) -= mat_next.block<1, 6>(1, 0);
    lb_smooth_(4 * i + 1 + row_offset, 0) = -kEpsilon; // kEpsilon
    ub_smooth_(4 * i + 1 + row_offset, 0) = kEpsilon;
    // 二阶导
    // 6: -b <= AddY <= b
    constraint_smooth_.block<1, 6>(4 * i + 2 + row_offset, 6 * i + col_offset) += mat_pre.block<1, 6>(2, 0);
    constraint_smooth_.block<1, 6>(4 * i + 2 + row_offset, 6 * i + 6 + col_offset) -= mat_next.block<1, 6>(2, 0);
    lb_smooth_(4 * i + 2 + row_offset, 0) = -kEpsilon; // kEpsilon
    ub_smooth_(4 * i + 2 + row_offset, 0) = kEpsilon;
    // 三阶导
    // 7: -b <= AdddY <= b
    constraint_smooth_.block<1, 6>(4 * i + 3 + row_offset, 6 * i + col_offset) += mat_pre.block<1, 6>(3, 0);
    constraint_smooth_.block<1, 6>(4 * i + 3 + row_offset, 6 * i + 6 + col_offset) -= mat_next.block<1, 6>(3, 0);
    lb_smooth_(4 * i + 3 + row_offset, 0) = -kEpsilon; // kEpsilon
    ub_smooth_(4 * i + 3 + row_offset, 0) = kEpsilon;
  }
  return true;
}

bool SplineSolver::AddBoundaryConstraint() {
  // 最麻烦的地方，需要约束所有的anchor的位置，包括起点，所以起点的位置就不是定死的了。
  //
  constexpr double lateral_bound = 0.1;
  constexpr double longitudinal_bound = 0.3;
  int col_offset = 6 * num_of_splines_;

  for (auto i = 0; i < num_of_anchor_; i++) {
    double t_offset = anchor_t_offset_[i];
    auto knot_index = anchor_knot_index_[i];
    double heading = anchor_[i].heading;
    double anchor_x = std::cos(heading) * anchor_[i].x + std::sin(heading) * anchor_[i].y;
    double anchor_y = -std::sin(heading) * anchor_[i].x + std::cos(heading) * anchor_[i].y;

    // t_poly [1, t^2, t^3, t^4, t^5]
    Eigen::MatrixXd t_poly = Eigen::MatrixXd::Zero(1, 6);
    t_poly(0, 0) = 1.0;
    for (auto j = 1; j < 6; j++) {
      t_poly(0, j) = t_poly(0, j - 1) * t_offset;
    }

    // x轴上下界 anchor_x - delta <= cos(theta)*dx + sin(theta)* dy <= anchor_x
    // + delta
    constraint_bound_.block<1, 6>(i, 6 * knot_index) += std::cos(heading) * t_poly;
    constraint_bound_.block<1, 6>(i, 6 * knot_index + col_offset) += std::sin(heading) * t_poly;
    lb_bound_(i, 0) = anchor_x - longitudinal_bound;
    ub_bound_(i, 0) = anchor_x + longitudinal_bound;

    // y轴上下界 anchor_y-delta <= -sin(theta)*dx+ cos(theta)*dy <= anchor_y
    // +delata
    constraint_bound_.block<1, 6>(i + num_of_anchor_, 6 * knot_index) -= std::sin(heading) * t_poly;
    constraint_bound_.block<1, 6>(i + num_of_anchor_, 6 * knot_index + col_offset) += std::cos(heading) * t_poly;
    lb_bound_(i + num_of_anchor_, 0) = anchor_y - lateral_bound;
    ub_bound_(i + num_of_anchor_, 0) = anchor_y + lateral_bound;
  }
  return true;
}

bool SplineSolver::InitQPSolverSetting() {
  // 设置 Kernel
  std::cout << "=================" << std::endl;
  std::cout << "InitQPSolverSetting" << std::endl;

  
  AddSecondDerivativeKernel(weights_.w_second_derivative);
  AddThridDerivativeKernel(weights_.w_third_derivative);
  AddRegularizationKernel(weights_.w_regularization);
  std::cout << "设置 Kernel 完成" << std::endl;

  // 设置 constraints and upper/lower boundary
  AddKnotSmoothConstraint();
  AddBoundaryConstraint();
  // double start_point_heading = anchor_.front().heading;
  // AddPointDirectionConstraint(start_point_heading);
  // constraint_ << constraint_angle_, constraint_smooth_, constraint_bound_;
  // lower_bound_ << lb_angle_, lb_smooth_, lb_bound_;
  // upper_bound_ << ub_angle_, ub_smooth_, ub_bound_;

  // FIX: 2024-11-04 
  // 转换成起始点的位置+方向约束
  // fmt::print("s_x: {:.2f}\n", s_x);
  // fmt::print("s_y: {:.2f}\n", s_y);
  // fmt::print("s_head: {:.2f}\n", s_head);
  // fmt::print("e_x: {:.2f}\n", e_x);
  // fmt::print("e_y: {:.2f}\n", e_y);
  // fmt::print("e_head: {:.2f}\n", e_head);
  // fmt::print("e_t_offset: {:.2f}\n", e_t_offset);

  AddStartEndPointConstraint(s_x, s_y, s_head, e_x, e_y, e_head, e_t_offset);
  constraint_ << constraint_startend_, constraint_smooth_, constraint_bound_;
  lower_bound_ << lb_startend_, lb_smooth_, lb_bound_;
  upper_bound_ << ub_startend_, ub_smooth_, ub_bound_;
  std::cout << "设置 Constraints 完成" << std::endl;

  // std::cout << "constraint_startend_" << std::endl;
  // std::cout << constraint_startend_ << std::endl;
  // std::cout << "lb_startend_" << std::endl;
  // std::cout << lb_startend_ << std::endl;
  // std::cout << "ub_startend_" << std::endl;
  // std::cout << ub_startend_ << std::endl;
  
  // // csv save file
  // csv_writer_.setFilenameWithTimestamp();
  // csv_writer_.addSheet(constraint_startend_, "constraint_startend_");
  // std::cout << constraint_smooth_ << std::endl;

  // 设置solver
  solver_.setDataDiemension(num_of_params_, num_constraint_);

  // 初始化solver矩阵和向量
  Eigen::SparseMatrix<double> hessian = kernel_.sparseView();
  Eigen::VectorXd gradient = Eigen::VectorXd::Zero(num_of_params_);
  Eigen::SparseMatrix<double> linear_matrix = constraint_.sparseView();
  Eigen::VectorXd lower_bound = lower_bound_;
  Eigen::VectorXd upper_bound = upper_bound_;
  std::cout << "初始化solver矩阵和向量" << std::endl;

  // 使用QpSolver类设置问题
  solver_.setHessianMatrix(hessian);
  solver_.setGradient(gradient);
  solver_.setLinearConstraintsMatrix(linear_matrix);
  solver_.setLowerBound(lower_bound);
  solver_.setUpperBound(upper_bound);
  std::cout << "初始化QpSolver类 完成" << std::endl;

  // 初始化并求解
  solver_.initializeSolver();
  return true;
}

bool SplineSolver::SolveProblem() {
  auto resolution = solver_.Solve();
  // std::cout << resolution << std::endl;
  result_ = resolution;
  return true;
}

std::vector<ReferencePoint> SplineSolver::GetResolution() {
  //result
  std::vector<ReferencePoint> smooth_points;
  smooth_points.reserve(num_of_anchor_);

  //为每一段knot 都计算一个lambda函数 用于计算弧长。
  int index_offset = num_of_splines_ * 6;
  std::vector<std::function<double(double)> > coef_func;
  std::vector<std::vector<double> > coef_x;
  std::vector<std::vector<double> > coef_y;
  coef_func.reserve(num_of_splines_);
  coef_x.reserve(num_of_splines_);
  coef_y.reserve(num_of_splines_);


  // 循环计算对应的lambda函数 sqrt(dx*dx +dy*dy)
  for (auto i = 0; i < num_of_splines_; i++) {
    // 截取对应部分的a0,a1,a2,a3,a4,a5
    Eigen::VectorXd subvec_x = result_.segment(6 * i, 6);
    Eigen::VectorXd subvec_y = result_.segment(6 * i + index_offset, 6);
    //转换 vector
    auto vec_x = std::vector<double>(subvec_x.data(), subvec_x.data() + subvec_x.size());
    auto vec_y = std::vector<double>(subvec_y.data(), subvec_y.data() + subvec_y.size());
    // 计算匿名函数
    // lambda function
    auto CalculateArcLength = [vec_x, vec_y](double t) -> double {
      double dx = 0.0;
      double dy = 0.0;
      for (auto j = 5; j >= 1; --j) {
        dx = dx * t + vec_x[j] * j;
        dy = dy * t + vec_y[j] * j;
      }
      return std::sqrt(dx * dx + dy * dy); // 参数方程弧长积分
    };
    // 加入对应的lambda数组 coef_x coef_y
    coef_func.emplace_back(std::move(CalculateArcLength));
    coef_x.emplace_back(std::move(vec_x));
    coef_y.emplace_back(std::move(vec_y));
  }

  //
  //
  // {
  //   std::cout << "=========================" << std::endl;
  //   std::cout << "打印knot端点信息" << std::endl;
  //   for (auto i = 0; i < num_of_splines_ - 1; i++) {
  //     double prex_x = std::accumulate(coef_x[i].begin(), coef_x[i].end(), 0.0);
  //     double next_x = coef_x[i + 1][0];
  //     double prex_y = std::accumulate(coef_y[i].begin(), coef_y[i].end(), 0.0);
  //     double next_y = coef_y[i + 1][0];
  //     fmt::print("index :{}, when t = 1, x = {:.5f}, y ={:.5f}\n", i, prex_x,
  //                prex_y);
  //     fmt::print("index :{}, when t = 0, x = {:.5f}, y ={:.5f}\n", i + 1,
  //                next_x, next_y);
  //   }
  // }

  // 先计算每段的knot的弧长再分anchor逐个计算相对弧长，最后还原。
  std::vector<double> knot_arc_length(num_of_splines_, 0.0);
  std::vector<double> knot_accumulated(num_of_splines_ + 1, 0.0);
  double acc_s = 0.0;
  for (auto i = 0; i < num_of_splines_; ++i) {
    knot_arc_length[i] = GaussLegendreIntegrate4(coef_func[i], 0.0, 1.0);
  }
  for (auto i = 1; i < num_of_splines_ + 1; ++i) {
    knot_accumulated[i] = knot_accumulated[i - 1] + knot_arc_length[i];
  }

  // // 打印积分后的弧长信息，用于确定分段的弧长是否用的合理
  // {
  //   std::cout << "==================" << std::endl;
  //   std::cout << "打印积分后的弧长信息" << std::endl;
  //   int i = 0;
  //   for (auto &l : knot_arc_length) {
  //     fmt::print("arc index: {}  with arc length: {}\n", i++, l);
  //   }
  // }

  // 计算每个ref_point的信息 s/x/y/heading/kappa/dkappa
  for (auto i = 0; i < num_of_anchor_; ++i) {
    int knot_index = anchor_knot_index_[i];
    double t_offset = anchor_t_offset_[i];
    int index_offset = 6 * num_of_splines_;

    //   (╯°□°)╯︵ ┻━┻   计算 x dx ddx ddx   ┻━┻︵ ヽ(°□°ヽ)
    auto point_info = GetSplinePointInfo(coef_x[knot_index], coef_y[knot_index], t_offset);
    double final_x = ref_x + std::get<0>(point_info);
    double final_y = ref_y + std::get<1>(point_info);
    double kappa = std::get<2>(point_info);
    double dkappa = std::get<3>(point_info);
    double heading = std::get<4>(point_info);
    double arc_length_offset = knot_accumulated[knot_index] + GaussLegendreIntegrate4(coef_func[knot_index], 0.0, t_offset);
    smooth_points.emplace_back(arc_length_offset, final_x, final_y, kappa, dkappa, heading);
  }

  return smooth_points;
}