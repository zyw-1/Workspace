//
// Created by faye on 24-8-27.
//
#include "utils_math.h"

#include <array>
#include <cmath>
#include <iostream>
#include <chrono>

int main() {
    std::array<double, 4> coef = {3.0, 6.0, 15};

    auto CalculateArcLength = [&coef](double t) -> double {
        return std::sqrt(1 + (6 * t + 6) * (6 * t + 6));
    };

    auto start = std::chrono::high_resolution_clock::now();

    auto arc_length = GaussLegendreIntegrate4(CalculateArcLength, 0.0, 1.0);

    // 获取结束时间点
    auto end = std::chrono::high_resolution_clock::now();
    // 计算耗时，单位为毫秒
    std::chrono::duration<double, std::milli> duration = end - start;
    // 输出耗时
    std::cout << "Function execution time: " << duration.count() << " ms" << std::endl;
    std::cout << arc_length << std::endl;


    auto res = PolyValue5th({1,2,3,4,5,6},1);
    auto res1 = PolyValue5thDerivate({1,1,1,1,1,1},1);
    std::cout<<res1<<std::endl;


}
