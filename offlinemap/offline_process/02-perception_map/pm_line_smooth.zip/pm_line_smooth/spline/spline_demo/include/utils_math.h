//
// Created by faye on 8/22/24.
//

# pragma once

#include "base.h"

#include <vector>
#include <array>
#include <functional>





bool RemoveDuplicatePoints(std::vector<Point>*);

double NormalizeAngle(const double angel);

double AngleDiff(const double from, const double to);

// Spherical Linear Interpolation, for angle
double slerp(const double a0, const double t0, const double a1, const double t1, const double t);

// lerp = linear interpolation
double lerp(const double &x0, const double t0, const double &x1, const double t1, const double t);


bool ComputePathProfile(
        const std::vector<Point>& xy_points,
        std::vector<double>* headings, std::vector<double>* accumulated_s,
        std::vector<double>* kappas, std::vector<double>* dkappas);


struct GaussLegendre4 {
    std::array<double, 4> weights;
    std::array<double, 4> roots;

    GaussLegendre4() {
        // 初始化权重和根
        roots = {
            3.39981043584856264792e-01, -3.39981043584856264792e-01,
            8.61136311594052575248e-01, -8.61136311594052575248e-01
        };
        weights = {
            6.52145154862546142644e-01, 6.52145154862546142644e-01,
            3.47854845137453857383e-01, 3.47854845137453857383e-01
        };
    }
};


// 高斯-勒让德积分函数，接受std::function作为参数
double GaussLegendreIntegrate4(const std::function<double(double)>& fx, double lower_bound, double upper_bound);

// 5阶次多项式数值计算
double PolyValue5th(const std::vector<double>& poly, double t);

double PolyValue5thDerivate(const std::vector<double>& poly, double t);

double GetKappa(double dx, double ddx, double dy, double ddy);

std::tuple<double, double, double, double, double> GetSplinePointInfo(const std::vector<double>& coef_x, const std::vector<double>& coef_y, double t);