//
// Created by faye on 8/22/24.
//

#pragma once

#include <iostream>

struct ReferencePoint {
  double s;       // 路径累计距离
  double x;       // x 坐标
  double y;       // y 坐标
  double kappa;   // 曲率
  double dkappa;  // 曲率变化率
  double heading; // 航向角

  // 默认构造函数
  ReferencePoint() :
      s(0.0), x(0.0), y(0.0), kappa(0.0), dkappa(0.0), heading(0.0) {}

  // 带参数的构造函数
  ReferencePoint(double s_val, double x_val, double y_val, double kappa_val,
                 double dkappa_val, double heading_val) :
      s(s_val), x(x_val), y(y_val), kappa(kappa_val), dkappa(dkappa_val),
      heading(heading_val) {}

  // 复制构造函数
  ReferencePoint(const ReferencePoint &other) :
      s(other.s), x(other.x), y(other.y), kappa(other.kappa),
      dkappa(other.dkappa), heading(other.heading) {}
};

struct Point {
  double x; // x 坐标
  double y; // y 坐标

  // 默认构造函数
  Point() : x(0.0), y(0.0) {}

  // 带参数的构造函数
  Point(double x_val, double y_val) : x(x_val), y(y_val) {}

  // 复制构造函数
  Point(const Point &other) : x(other.x), y(other.y) {}
};

//	spline_order: 5
//	max_spline_length : 25.0
//	regularization_weight : 1.0e-5
//	regularization_weight : 1.0e-5
//	second_derivative_weight : 200.0
//	third_derivative_weight: 1000.0
struct SmootherParams {
  double anchor_interval;
  double knot_interval;
  double w_regularization;
  double w_second_derivative;
  double w_third_derivative;

  explicit SmootherParams(double t1, double t2, double w1, double w2,
                          double w3) :
      anchor_interval(t1), knot_interval(t2), w_regularization(w1),
      w_second_derivative(w2), w_third_derivative(w3) {}

  explicit SmootherParams() :
        anchor_interval(0.5), knot_interval(5.0), w_regularization(1.0e-5), w_second_derivative(200.0), w_third_derivative(1.0e6) {
    }
};
