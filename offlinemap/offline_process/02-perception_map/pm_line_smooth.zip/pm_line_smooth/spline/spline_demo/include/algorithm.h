#pragma once

#include "reference_line.h"
#include "spline_solver.h"
#include "base.h"

#include <vector>
#include <memory>



class Algorithm {
public:
    Algorithm() = default;
    ~Algorithm() = default;
    void initialize(std::vector<double> raw_x, std::vector<double> raw_y, double heading_start, double heading_end);  // 初始化算法
    std::vector<std::vector<double>> get_solution();  // 获取计算结果

private:
    std::vector<Point> raw_points_;
    std::shared_ptr<DiscretePointLines> line_ptr_ = nullptr;
    std::vector<double> resample_x_;
    std::vector<double> resample_y_;
    std::shared_ptr<SplineSolver> sovler_ptr_ = nullptr;
    std::vector<std::vector<double>> results_;
};
