//
// Created by faye on 8/22/24.
//

#pragma once

#include "base.h"
#include "osqp_interface.h"
#include "csv_writer.h"

#include <Eigen/Dense>
#include <fmt/core.h>

#include <vector>

using Eigen::MatrixXd;
using Eigen::VectorXd;

class SplineSolver {
public:
    explicit SplineSolver(const std::vector<ReferencePoint> &anchor);
    //
    void SetStartEndHeading(double start_heading, double end_heading){
        extern_start_head = start_heading;
        extern_end_head = end_heading;
        // TODO 这里需要判断外部给的heading是否符合需求
        s_head = extern_start_head;
        e_head = extern_end_head;
    }

    // 设置矩阵大小尺寸
    bool SetMatrixSize();

    // 二阶导数连续 kernel
    bool AddSecondDerivativeKernel(const double weight);

    // 二阶导数连续 kernel
    bool AddThridDerivativeKernel(const double weight);

    // 正则约束 kernel
    bool AddRegularizationKernel(const double weight);

    // 起点终点方向 约束
    bool AddPointDirectionConstraint(const double raw_heading);

    // 追加需求 起点终点的位置和heading方向
    // FIX 2024-11-03 用来补充卢岩需求，替代 AddPointDirectionConstraint使用
    bool AddStartEndPointConstraint(double s_x, double s_y, double s_head, double e_x, double e_y, double e_head, double e_t_offset);

    // 连接点平滑约束
    bool AddKnotSmoothConstraint();

    // 添加上限下限偏移约束
    bool AddBoundaryConstraint();

    bool InitQPSolverSetting();

    bool SolveProblem();

    static std::pair<size_t, double> FindIndex(const std::vector<double> &,
                                               double);

    static constexpr double kEpsilon = 1.0e-6;
    // bool IsResultSolid();

    std::vector<ReferencePoint> GetResolution();
    // void GetResolution();

    const std::vector<ReferencePoint> & GetAnchorPoints() {
        return anchor_;
    }


private:
    // basic information
    // Eigen api uses INT to describe dimensions
    const int spline_order = 5;

    int num_of_anchor_;
    double ref_x = 0.0;
    double ref_y = 0.0;
    double ref_s = 0.0;

    int num_of_params_;
    int num_of_splines_;
    double raw_length_;
    double knot_sclar_;

    std::vector<ReferencePoint> anchor_;
    std::vector<ReferencePoint> smoothed_;

    std::vector<double> knot_s_; //[0,1,2,3,4,5] t=0/1/2..时 对应的s
    std::vector<double> anchor_t_offset_; // each anchorpoints t offset on its own segment;
    std::vector<int> anchor_knot_index_; // each anchorpoints in which knot segments;

    // QP params
    MatrixXd kernel_; // H
    MatrixXd constraint_; // AX >= lb
    VectorXd upper_bound_; // upper bound
    VectorXd lower_bound_; // lower bound
    SmootherParams weights_;

    MatrixXd constraint_angle_;
    MatrixXd constraint_smooth_;
    MatrixXd constraint_bound_;
    VectorXd lb_angle_;
    VectorXd lb_smooth_;
    VectorXd lb_bound_;
    VectorXd ub_angle_;
    VectorXd ub_smooth_;
    VectorXd ub_bound_;

    // 约束是纵向拼接，有3个部分
    // 连接knot处 0/1/2/3 order 平滑
    // 起点终点 的heading方向与拟合点一致
    // 所有anchor的 横纵向bound的上限界限
    int num_constraint_angle_;
    int num_constraint_smooth_;
    int num_constraint_bound_;
    int num_constraint_;

    // 起始点的位置+1阶导heading约束
    // FIX 2024-11-03 FOR 卢岩使用，用于替代原始的单一方向约束
    double s_head;
    double s_x;
    double s_y;
    double e_head;
    double e_x;
    double e_y;
    double e_t_offset;
    double extern_start_head;
    double extern_end_head;
    MatrixXd constraint_startend_;
    VectorXd lb_startend_;
    VectorXd ub_startend_;
    int num_constraint_startend_;

    // OSQP sovler interface
    QpSolver solver_;
    VectorXd result_;

    CsvWriter csv_writer_;
};
