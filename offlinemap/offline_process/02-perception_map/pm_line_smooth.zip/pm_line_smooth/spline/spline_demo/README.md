# 五次多项式插值 
5th-order polynomial interpolation

# 主要流程
1. 检查输入点, 无折返无突变无相同点
2. 直接输出profile计算的结果 对比输入的起始和结束的heading是不是相差不大 则不报错
3. 计算结果
4. 输出vector，需要分别输出对应 raw_x/y smooth_x|y profile_x|y
5. 使用python 保存成对应的csv或者xlsx文件


# SO 主要结构
1. Solver 对外的直接接口，使用pybind11传递数据
    1. 接受py::array_t<double>，转换成 std::vector<double> 给打包的 algorithm类
    2. 将结果 std::vector<std::vector<double>> 转换为 2D numpy array py::array_t<double>
2. Algorithm 
    1. initialize 接受原始点的坐标的两个vec
    2. get_solution 返回smooth结果的两个vec 
3. SplineSolver 主要的算法计算类


# 算法类
1. DiscretePointLine 散点类
    1. ComputeProfile 散点计算对应的 heading/curvature
    2. FindIndex 返回给定offset s 上一个index和下一个index
    3. GetAnchorPoint 给定offset s计算对应的 Point数据
    4. Resampling 对输出点序进行重采样

2. SplineSolver 求解器
    1. SetMatrixSize 
    2. AddSecondDerivativeKernel
    3. AddThridDerivativeKernel
    4. AddRegularizationKernel
    5. AddPointDirectionConstraint
    6. AddKnotSmoothConstraint
    7. AddBoundaryConstraint
    8. InitQPSolverSetting
    9. SolveProblem
    10. FindIndex
    11. GetResolution
    12. GetAnchorPoints