import pandas as pd
import numpy as np
import os,sys
from matplotlib import pyplot as plt

sys.path.append(os.path.join(os.path.dirname(__file__), "static_libs"))

df = pd.read_csv("data.csv")
x = df["x"].to_numpy()
y = df["y"].to_numpy()

# 计算出来的heading start/end
# -1.01517   -2.58754
heading_start =  -1.01517
heading_end = -2.58754

import pybind_solver
solver = pybind_solver.Solver()
solver.init(x, y, heading_start, heading_end)

result = solver.get_solution()

# 绘图对比不同的结果
for arr in result:
    print("="*20)
    print(arr)





