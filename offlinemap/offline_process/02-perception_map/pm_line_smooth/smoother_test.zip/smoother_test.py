import pandas as pd
import numpy as np
import os,sys
sys.path.append(os.path.join(os.path.dirname(__file__), "build"))

df = pd.read_csv("data.csv")

x = df["x"].to_numpy()
y = df["y"].to_numpy()


import pybind_solver
solver = pybind_solver.Solver()
solver.init(x,y)

result = solver.get_solution()

for arr in result:
    print("="*20)
    print(arr)





