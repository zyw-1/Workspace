//
// Created by faye on 8/21/24.
//

#pragma once

#include <vector>
#include "base.h"

class DiscretePointLines{
public:
  DiscretePointLines(const std::vector<double>& raw_x,
  const std::vector<double>& raw_y);
  
  // 散点计算对应的 heading/curvature
  void ComputeProfile();

  // 返回给定offset s 上一个index和下一个index
  std::pair<size_t, size_t> FindIndex(double s);

  // 给定offset s计算对应的 Point数据
  ReferencePoint GetAnchorPoint(double s);

  // 对输出点序进行重采样
  std::vector<ReferencePoint> Resampling();

// private:

  int num_points_;

  std::vector<Point> raw_points_;
  std::vector<double> s_;
  std::vector<double> x_;
  std::vector<double> y_;
  std::vector<double> heading_;
  std::vector<double> kappa_;
  std::vector<double> dkappa_;

  SmootherParams smoother_params_;

};


