#pragma once

#include "OsqpEigen/OsqpEigen.h"
#include <Eigen/Dense>

class QpSolver {
public:

  QpSolver() = default;

  void setDataDiemension(int num_variables, int num_constraints) {
    solver_.data()->setNumberOfVariables(num_variables);
    solver_.data()->setNumberOfConstraints(num_constraints);
  }


  // 设置 Hessian 矩阵
  void setHessianMatrix(const Eigen::SparseMatrix<double> &hessian_matrix) {
    hessian_ = hessian_matrix;
    if (!solver_.data()->setHessianMatrix(hessian_)) {
      throw std::runtime_error("Failed to set Hessian matrix");
    }
  }

  // 设置梯度向量
  void setGradient(const Eigen::VectorXd &gradient_vector) {
    gradient_ = gradient_vector;
    if (!solver_.data()->setGradient(gradient_)) {
      throw std::runtime_error("Failed to set gradient vector");
    }
  }

  // 设置线性约束矩阵
  void setLinearConstraintsMatrix(
      const Eigen::SparseMatrix<double> &linear_constraints_matrix) {
    linear_matrix_ = linear_constraints_matrix;
    if (!solver_.data()->setLinearConstraintsMatrix(linear_matrix_)) {
      throw std::runtime_error("Failed to set linear constraints matrix");
    }
  }

  // 设置下限向量
  void setLowerBound(const Eigen::VectorXd &lower_bound_vector) {
    lower_bound_ = lower_bound_vector;
    if (!solver_.data()->setLowerBound(lower_bound_)) {
      throw std::runtime_error("Failed to set lower bound vector");
    }
  }

  // 设置上限向量
  void setUpperBound(const Eigen::VectorXd &upper_bound_vector) {
    upper_bound_ = upper_bound_vector;
    if (!solver_.data()->setUpperBound(upper_bound_)) {
      throw std::runtime_error("Failed to set upper bound vector");
    }
  }

  // 初始化求解器
  void initializeSolver() {
    solver_.settings()->setVerbosity(false);
    solver_.settings()->setWarmStart(true);
    if (!solver_.initSolver()) {
      throw std::runtime_error("Failed to initialize the QP solver");
    }
  }

  // 求解QP问题
  Eigen::VectorXd Solve() {
    if (solver_.solveProblem() != OsqpEigen::ErrorExitFlag::NoError) {
      throw std::runtime_error("Failed to solve the QP problem");
    }
    return solver_.getSolution();
  }

private:
  OsqpEigen::Solver solver_; // OSQP求解器对象

  Eigen::SparseMatrix<double> hessian_;       // Hessian 矩阵
  Eigen::VectorXd gradient_;                  // 梯度向量
  Eigen::SparseMatrix<double> linear_matrix_; // 线性约束矩阵
  Eigen::VectorXd lower_bound_;               // 下限向量
  Eigen::VectorXd upper_bound_;               // 上限向量
};
