#include <iostream>
#include <vector>
#include <ctime>
#include <Eigen/Dense>
#include <fmt/core.h>
#include "rapidcsv.h"

class CsvWriter {
public:
    // 默认构造函数
    CsvWriter() = default;

    // 函数：接受 Eigen::MatrixXd
    void addSheet(const Eigen::MatrixXd& matrix, const std::string& sheetName) {
        std::vector<std::vector<double>> data(matrix.rows(), std::vector<double>(matrix.cols()));

        // 将 Eigen::MatrixXd 数据转换为 std::vector<std::vector<double>>
        for (int i = 0; i < matrix.rows(); ++i) {
            for (int j = 0; j < matrix.cols(); ++j) {
                data[i][j] = matrix(i, j);
            }
        }

        sheets[sheetName] = data;  // 将数据存储在指定的 sheetName 下
    }

    // 函数：接受 Eigen::VectorXd
    void addSheet(const Eigen::VectorXd& vector, const std::string& sheetName) {
        std::vector<std::vector<double>> data(vector.size(), std::vector<double>(1));

        // 将 Eigen::VectorXd 数据转换为 std::vector<std::vector<double>>
        for (int i = 0; i < vector.size(); ++i) {
            data[i][0] = vector(i);
        }

        sheets[sheetName] = data;  // 将数据存储在指定的 sheetName 下
    }

    // 设置文件名函数
    void setFilename(const std::string& filename) {
        filename_ = filename;
    }

    // 设置文件名函数，使用当前时间作为时间戳
    void setFilenameWithTimestamp(const std::string& prefix = "output_") {
        auto t = std::time(nullptr);
        auto tm = *std::localtime(&t);

        // 使用 fmt 库格式化时间戳
        filename_ = fmt::format("{}{:04}{:02}{:02}{:02}{:02}{:02}.csv",
                                prefix,
                                tm.tm_year + 1900,
                                tm.tm_mon + 1,
                                tm.tm_mday,
                                tm.tm_hour,
                                tm.tm_min,
                                tm.tm_sec);
    }

    // 手动保存函数
    void saveToFile() const {
        if (filename_.empty()) {
            std::cerr << "Error: Filename is not set!" << std::endl;
            return;
        }

        rapidcsv::Document doc("", rapidcsv::LabelParams(-1, -1), rapidcsv::SeparatorParams(','));

        // 遍历每个 sheet，并将数据写入 CSV 文件
        for (const auto& sheet : sheets) {
            const std::vector<std::vector<double>>& data = sheet.second;
            int rowIndex = doc.GetRowCount();  // 获取当前文档中已有的行数，以确保新数据添加在后续行
            for (const auto& row : data) {
                doc.InsertRow(rowIndex++, row);
            }
        }

        doc.Save(filename_);
        std::cout << "Data saved to " << filename_ << std::endl;
    }

    // 析构函数，自动保存 CSV 文件
    ~CsvWriter() {
        if (!filename_.empty()) {
            saveToFile();  // 在析构函数中保存文件
        }
    }

private:
    std::string filename_;  // CSV 文件名
    std::map<std::string, std::vector<std::vector<double>>> sheets;  // 存储所有 sheet 数据
};

// // 创建全局对象
// CsvWriter globalCsvWriter;
//
// int main() {
//     // 示例：使用 Eigen::MatrixXd
//     Eigen::MatrixXd matrix(3, 3);
//     matrix << 1.1, 2.2, 3.3,
//               4.4, 5.5, 6.6,
//               7.7, 8.8, 9.9;
//     globalCsvWriter.addSheet(matrix, "MatrixSheet");
//
//     // 示例：使用 Eigen::VectorXd
//     Eigen::VectorXd vector(3);
//     vector << 10.1, 20.2, 30.3;
//     globalCsvWriter.addSheet(vector, "VectorSheet");
//
//     // 使用时间戳设置 CSV 文件名
//     globalCsvWriter.setFilenameWithTimestamp();
//
//     // 可手动保存（这一步现在是可选的，因为在析构函数中也会自动保存）
//     globalCsvWriter.saveToFile();
//
//     return 0;
// }
