//
// Created by faye on 24-9-19.
//

#include "algorithm.h"



void Algorithm::initialize(std::vector<double> raw_x, std::vector<double> raw_y, double heading_start, double heading_end) {

    size_t num_of_points = raw_x.size();
    raw_points_.reserve(num_of_points); // 预留空间以避免多次分配
    for (size_t i = 0; i < num_of_points; ++i) {
        raw_points_.emplace_back(raw_x[i], raw_y[i]);
    }

    line_ptr_= std::make_shared<DiscretePointLines>(raw_x, raw_y);
    line_ptr_->ComputeProfile();

    auto points = line_ptr_->Resampling();
    size_t resample_point_num = points.size();

    resample_x_.reserve(resample_point_num);
    resample_y_.reserve(resample_point_num);

    for (auto &p: points) {
        // fmt::print("s:{:.4f}， x:{:.4f}, y:{:.4f}, kappa:{:.4f}, "
        //            "dkappa:{:.4f},heading:{:.4f}\n",
        //            p.s, p.x, p.y, p.kappa, p.dkappa, p.heading);
        resample_x_.emplace_back(p.x);
        resample_y_.emplace_back(p.y);
    }


    sovler_ptr_ = std::make_shared<SplineSolver>(points);
    sovler_ptr_->SetStartEndHeading(heading_start, heading_end);  
    sovler_ptr_->SetMatrixSize();
    sovler_ptr_->InitQPSolverSetting();
}

std::vector<std::vector<double>> Algorithm::get_solution() {

    sovler_ptr_->SolveProblem();
    auto smooth_point = sovler_ptr_->GetResolution();

    size_t smooth_point_num = smooth_point.size();

    // 提前分配空间，避免重复分配
    std::vector<double> smooth_x(smooth_point_num);
    std::vector<double> smooth_y(smooth_point_num);
    std::vector<double> smooth_heading(smooth_point_num);
    std::vector<double> smooth_kappa(smooth_point_num);
    std::vector<double> smooth_dkappa(smooth_point_num);
    std::vector<double> smooth_s(smooth_point_num);

    size_t index = 0;
    for (auto &p: smooth_point) {
        smooth_x[index] = p.x;
        smooth_y[index] = p.y;
        smooth_s[index] = p.s;
        smooth_heading[index] = p.heading;
        smooth_kappa[index] = p.kappa;
        smooth_dkappa[index] = p.dkappa;
        ++index;
    }

    // 直接通过 std::move 将局部的 vector 移动到 results，避免拷贝
    std::vector<std::vector<double>> results(6);
    results[0] = std::move(smooth_x);
    results[1] = std::move(smooth_y);
    results[2] = std::move(smooth_s);
    results[3] = std::move(smooth_heading);
    results[4] = std::move(smooth_kappa);
    results[5] = std::move(smooth_dkappa);

    return results;
}