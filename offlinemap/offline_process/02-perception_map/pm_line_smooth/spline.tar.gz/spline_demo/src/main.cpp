//
// Created by faye on 8/21/24.
//
#include "reference_line.h"
#include "spline_solver.h"
#include "utils_math.h"

#include "matplotlibcpp.h"
#include "rapidcsv.h"
#include <fmt/core.h>
#include <Eigen/Dense>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>

namespace plt = matplotlibcpp;
namespace fs = std::filesystem;

fs::path cwd = fs::current_path();
fs::path csv_path = "../data.csv";

int main() {

    // 加载数据
    std::cout << "=================" << std::endl;
    std::cout << "加载数据" << std::endl;
    rapidcsv::Document doc("../data.csv", rapidcsv::LabelParams(0, -1));
    std::vector<double> raw_x = doc.GetColumn<double>("x");
    std::vector<double> raw_y = doc.GetColumn<double>("y");
    size_t num_of_points = raw_x.size();
    std::vector<Point> raw_points;
    raw_points.reserve(num_of_points); // 预留空间以避免多次分配

    for (size_t i = 0; i < num_of_points; ++i) {
        // emplace automatic call Points' construction func
        raw_points.emplace_back(raw_x[i], raw_y[i]);
    }

    // 重新线性插值计算对应点, 必须过原来的起始点和终点
    std::cout << "=================" << std::endl;
    std::cout << "重新线性插值计算对应点" << std::endl;

    DiscretePointLines line(raw_x, raw_y);
    line.ComputeProfile();
    auto points = line.Resampling();

    int resample_point_num = points.size();
    std::vector<double> resample_x;
    std::vector<double> resample_y;
    std::vector<double> resample_s;
    std::vector<double> resample_heading;
    std::vector<double> resample_kappa;
    std::vector<double> resample_dkappa;
    resample_x.reserve(resample_point_num);
    resample_y.reserve(resample_point_num);
    resample_s.reserve(resample_point_num);
    resample_heading.reserve(resample_point_num);
    resample_kappa.reserve(resample_point_num);
    resample_dkappa.reserve(resample_point_num);
    

    for (auto &p: points) {
        // fmt::print("s:{:.4f}， x:{:.4f}, y:{:.4f}, kappa:{:.4f}, "
        //            "dkappa:{:.4f},heading:{:.4f}\n",
        //            p.s, p.x, p.y, p.kappa, p.dkappa, p.heading);
        resample_x.emplace_back(p.x);
        resample_y.emplace_back(p.y);
        resample_s.emplace_back(p.s);
        resample_heading.emplace_back(p.heading);
        resample_kappa.emplace_back(p.kappa);
        resample_dkappa.emplace_back(p.dkappa);
    }

    double heading_start = points.front().heading;
    double heading_end = points.back().heading;


    std::cout << "=================" << std::endl;
    std::cout << "init solver" << std::endl;

    SplineSolver spline_solver(points);
    std::cout << heading_start<< heading_end<< std::endl;
    spline_solver.SetStartEndHeading(heading_start, heading_end);    
    spline_solver.InitQPSolverSetting();
    auto res = spline_solver.SolveProblem();
    auto smooth_point = spline_solver.GetResolution();

    std::cout << "=================" << std::endl;
    std::cout << "GetResolution from solver" << std::endl;
    
    int smooth_point_num = smooth_point.size();
    std::vector<double> smooth_x;
    std::vector<double> smooth_y;
    std::vector<double> smooth_heading;
    std::vector<double> smooth_kappa;
    std::vector<double> smooth_dkappa;
    std::vector<double> smooth_s;

    smooth_x.reserve(smooth_point_num);
    smooth_y.reserve(smooth_point_num);
    smooth_heading.reserve(smooth_point_num);
    smooth_kappa.reserve(smooth_point_num);
    smooth_dkappa.reserve(smooth_point_num);
    smooth_s.reserve(smooth_point_num);


    for (auto &p: smooth_point) {
        // fmt::print("s:{:.4f}， x:{:.4f}, y:{:.4f}, kappa:{:.4f}, "
        //            "dkappa:{:.4f},heading:{:.4f}\n",
        //            p.s, p.x, p.y, p.kappa, p.dkappa, p.heading);
        smooth_x.emplace_back(p.x);
        smooth_y.emplace_back(p.y);
        smooth_s.emplace_back(p.s);
        smooth_heading.emplace_back(p.heading);
        smooth_kappa.emplace_back(p.kappa);
        smooth_dkappa.emplace_back(p.dkappa);
    }

    // plt::subplot(4,1,1);
    // plt::plot(smooth_s);
    // plt::subplot(4,1,2);
    // plt::plot(smooth_heading);
    // plt::subplot(4,1,3);
    // plt::plot(smooth_kappa);
    // plt::subplot(4,1,4);
    // plt::plot(smooth_dkappa);
    // plt::show();
    // plt::close();
    
    // =================
    // Linestring
    // 绘制不同颜色的线条
    plt::plot(raw_x, raw_y, {{"color", "red"}, {"marker", "o"},{"label", "raw"}});  // 线条
    plt::plot(resample_x, resample_y, {{"color", "blue"}, {"marker", "+"},{"label", "resample"}});
    plt::plot(smooth_x, smooth_y, {{"color", "green"}, {"marker", "*"},{"label", "smooth"}});    // 线条
    // // 添加索引标签
    // for (size_t i = 0; i < smooth_point_num; ++i) {
    //   plt::text(smooth_x[i], smooth_y[i], std::to_string(i));
    //   plt::text(resample_x[i], resample_y[i], std::to_string(i));
    // }
    plt::legend(); // 添加图例
    plt::grid(true);
    plt::axis("equal"); // 设置轴为等比例
    plt::show(); // 显示图形
    plt::close();

    // =================
    // heading
    plt::plot(resample_s, resample_heading, {{"color", "blue"}, {"marker", "+"},{"label", "resample"}});
    plt::plot(smooth_s, smooth_heading, {{"color", "green"}, {"marker", "*"},{"label", "smooth"}});    // 线条
    plt::legend(); // 添加图例
    plt::grid(true);
    plt::show(); // 显示图形
    plt::close();

    // =================
    // kappa
    plt::plot(resample_s, resample_kappa, {{"color", "blue"}, {"marker", "+"},{"label", "resample"}});
    plt::plot(smooth_s, smooth_kappa, {{"color", "green"}, {"marker", "*"},{"label", "smooth"}});    // 线条
    plt::legend(); // 添加图例
    plt::grid(true);
    plt::show(); // 显示图形
    plt::close();

    return 0;
}
