//
// Created by faye on 8/21/24.
//
#include "reference_line.h"
#include "spline_solver.h"
#include "utils_math.h"

// #include "matplotlibcpp.h"
#include "rapidcsv.h"
#include <fmt/core.h>

#include <Eigen/Dense>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>

// namespace plt = matplotlibcpp;
namespace fs = std::filesystem;

fs::path cwd = fs::current_path();
fs::path csv_path = "../data.csv";

int main() {
  rapidcsv::Document doc("../data.csv", rapidcsv::LabelParams(0, -1));

  std::vector<double> raw_x = doc.GetColumn<double>("x");
  std::vector<double> raw_y = doc.GetColumn<double>("y");

  size_t num_of_points = raw_x.size();

  std::vector<Point> raw_points;
  raw_points.reserve(num_of_points); // 预留空间以避免多次分配

  for (size_t i = 0; i < num_of_points; ++i) {
    // emplace automatic call Points' construction func
    raw_points.emplace_back(raw_x[i], raw_y[i]);
  }

  std::cout << "here 1" << std::endl;

  DiscretePointLines line(raw_x, raw_y);
  line.ComputeProfile();
  auto points = line.Resampling();

  std::cout << "here 2" << std::endl;

  for (auto &p : points) {
    fmt::print("s:{:.4f}， x:{:.4f}, y:{:.4f}, kappa:{:.4f}, "
               "dkappa:{:.4f},heading:{:.4f}\n",
               p.s, p.x, p.y, p.kappa, p.dkappa, p.heading);
  }

  // plt::subplot(4,1,1);
  // plt::plot(accumulated_s);
  //
  // plt::subplot(4,1,2);
  // plt::plot(headings);
  //
  // plt::subplot(4,1,3);
  // plt::plot(kappas);
  // q
  // plt::subplot(4,1,4);
  // plt::plot(dkappas);
  //
  // plt::show();
  // plt::close();

  return 0;
}
