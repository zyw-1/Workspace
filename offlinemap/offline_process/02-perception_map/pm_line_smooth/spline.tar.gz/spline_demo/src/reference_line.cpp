//
// Created by faye on 8/21/24.
//

#include <cmath>
#include <stdexcept>
#include <vector>

#include "reference_line.h"
#include "utils_math.h"

#include <algorithm>

DiscretePointLines::DiscretePointLines(const std::vector<double> &raw_x,
                                       const std::vector<double> &raw_y) :
    x_(raw_x), y_(raw_y) {
  if (raw_x.size() != raw_y.size()) {
    throw std::runtime_error("size unmatched!");
  }

  num_points_ = raw_x.size();
  raw_points_.reserve(num_points_);

  for (auto i = 0; i < num_points_; i++) {
    raw_points_.emplace_back(raw_x[i], raw_y[i]);
  }
  if(! RemoveDuplicatePoints(&raw_points_)) {
    std::cerr << "errors!" << std::endl;
  }

  num_points_ = raw_points_.size();
}

void DiscretePointLines::ComputeProfile() {
  if (!ComputePathProfile(raw_points_, &heading_, &s_, &kappa_, &dkappa_)) {
    std::cerr << "errors!" << std::endl;
  }

  for (auto &heading : heading_) {
    heading = NormalizeAngle(heading);
  }
}

//return  prev_index, next_index
std::pair<size_t, size_t> DiscretePointLines::FindIndex(double s) {
  double start = 0.0;
  double length = s_.back();

  if (s < start+1.0e-5) {
    return {0,1};
  }else if(s>length+1.0e-5) {
    return {num_points_-2,num_points_-1};
  }

  auto it = std::upper_bound(s_.begin(), s_.end(), s);
  auto index = std::distance(s_.begin(), it);

  return {index-1, index};
}

ReferencePoint DiscretePointLines::GetAnchorPoint(double s) {
  auto res = FindIndex(s);
  int prev_index = res.first;
  int next_index = res.second;

  double lerp_x = lerp(x_[prev_index], s_[prev_index], x_[next_index],s_[next_index], s);
  double lerp_y = lerp(y_[prev_index], s_[prev_index], y_[next_index],s_[next_index], s);
  double lerp_s = s;
  double lerp_heading = slerp(heading_[prev_index], s_[prev_index], heading_[next_index],
  s_[next_index], s);
  double lerp_kappa = lerp(kappa_[prev_index], s_[prev_index], kappa_[next_index],s_[next_index], s);
  double lerp_dkappa = lerp(dkappa_[prev_index], s_[prev_index], dkappa_[next_index],s_[next_index], s);

  ReferencePoint p(lerp_s, lerp_x, lerp_y, lerp_kappa, lerp_dkappa, lerp_heading);
  return p;
}

std::vector<ReferencePoint> DiscretePointLines::Resampling() {

  const double interval = smoother_params_.anchor_interval;
  double length = s_.back();

  int num_of_anchors = static_cast<int>(std::floor(length/interval)) + 1;

  std::vector<ReferencePoint> points;
  points.reserve(num_of_anchors);

  points.emplace_back(s_.front(), x_.front(), y_.front(), kappa_.front(),
  dkappa_.front(),heading_.front());

  for(auto i = 1; i<num_of_anchors; i++) {
    points.emplace_back(GetAnchorPoint(i*interval));
  }

  double s_last = s_.back();
  double s_diff = std::abs((num_of_anchors-1)*interval - s_last);
  const double diff_max_tolerence = 1e-3;
  if(s_diff > diff_max_tolerence){
    points.pop_back();
    points.push_back(GetAnchorPoint(s_last));
  }



  // points.emplace_back(s_.back(), x_.back(), y_.back(), kappa_.back(),
  // dkappa_.back(),heading_.back());
  return points;
}
