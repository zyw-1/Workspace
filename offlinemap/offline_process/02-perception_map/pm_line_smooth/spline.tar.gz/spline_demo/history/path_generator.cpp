#include <iostream>
#include <vector>
#include "rapidcsv.h"
#include <filesystem>
#include <Eigen/Dense>
#include "matplotlibcpp.h"
#include "osqp/osqp.h"
#include "OsqpEigen/OsqpEigen.h"


namespace plt = matplotlibcpp;
namespace fs = std::filesystem;

fs::path cwd = fs::current_path();
fs::path csv_path = "data.csv";

constexpr double weight_smooth = 30.0;
constexpr double weight_length = 1.0;
constexpr double weight_similar = 10.0;
constexpr double limit_buffer = 0.3;


Eigen::SparseMatrix<double> hessian;
Eigen::VectorXd gradient;
Eigen::SparseMatrix<double> linearMatrix;
Eigen::VectorXd lowerBound;
Eigen::VectorXd upperBound;

using SparseMatrix = Eigen::SparseMatrix<double>;
using Triplet = Eigen::Triplet<double>;


bool initMat(const OsqpEigen::Solver *solver, const int &point_num, Eigen::VectorXd &ref_xy) {
    int n = point_num;
    int numOfVars = point_num * 2;
    int numOfCons = point_num * 2;

    // 创建一个 2n x 2n 的稀疏矩阵
    SparseMatrix matrix;
    matrix.resize(numOfVars, numOfVars);

    // 用 Triplet 列表填充矩阵
    std::vector<Triplet> tripletList;

    //  填充 n*n 的 H ，x的区域 ;  ，y的区域 n ~ 2*n-1
    //  先构造 triplet 再赋值给对应的 sparse matrix
    for (int i = 0; i < n; ++i) {
        if (i == 0) {
            tripletList.emplace_back(0, 0, weight_smooth + weight_length + weight_similar); //[0,0]
            tripletList.emplace_back(1, 0, -2.0 * weight_smooth - weight_length); //[1,0]
            tripletList.emplace_back(2, 0, weight_smooth); //[2,0]
            // y
            tripletList.emplace_back(n, n, weight_smooth + weight_length + weight_similar); //[0,0]
            tripletList.emplace_back(n + 1, n, -2.0 * weight_smooth - weight_length); //[1,0]
            tripletList.emplace_back(n + 2, n, weight_smooth); //[2,0]
        } else if (i == 1) {
            // x
            tripletList.emplace_back(0, 1, -2.0 * weight_smooth - weight_length); //[1,0]
            tripletList.emplace_back(1, 1, 5.0 * weight_smooth + 2.0 * weight_length + weight_similar);
            tripletList.emplace_back(2, 1, -4.0 * weight_smooth - weight_length); //[1,2]
            tripletList.emplace_back(3, 1, weight_smooth); //[1,3]
            //y
            tripletList.emplace_back(n, n + 1, -2.0 * weight_smooth - weight_length); //[1,0]
            tripletList.emplace_back(n + 1, n + 1, 5.0 * weight_smooth + 2.0 * weight_length + weight_similar);
            tripletList.emplace_back(n + 2, n + 1, -4.0 * weight_smooth - weight_length); //[1,2]
            tripletList.emplace_back(n + 3, n + 1, weight_smooth); //[1,3]
        } else if (i == n - 2) {
            // x
            tripletList.emplace_back(n - 4, n - 2, weight_smooth);
            tripletList.emplace_back(n - 3, n - 2, -4.0 * weight_smooth - weight_length);
            tripletList.emplace_back(n - 2, n - 2, 5.0 * weight_smooth + 2.0 * weight_length + weight_similar);
            tripletList.emplace_back(n - 1, n - 2, -2.0 * weight_smooth - weight_length);
            // y
            tripletList.emplace_back(2 * n - 4, 2 * n - 2, weight_smooth);
            tripletList.emplace_back(2 * n - 3, 2 * n - 2, -4.0 * weight_smooth - weight_length);
            tripletList.emplace_back(2 * n - 2, 2 * n - 2, 5.0 * weight_smooth + 2.0 * weight_length + weight_similar);
            tripletList.emplace_back(2 * n - 1, 2 * n - 2, -2.0 * weight_smooth - weight_length);
        } else if (i == n - 1) {
            // x
            tripletList.emplace_back(n - 3, n - 1, weight_smooth);
            tripletList.emplace_back(n - 2, n - 1, -2.0 * weight_smooth - weight_length);
            tripletList.emplace_back(n - 1, n - 1, weight_smooth + weight_length + weight_similar);
            // y
            tripletList.emplace_back(2 * n - 3, 2 * n - 1, weight_smooth);
            tripletList.emplace_back(2 * n - 2, 2 * n - 1, -2.0 * weight_smooth - weight_length);
            tripletList.emplace_back(2 * n - 1, 2 * n - 1, weight_smooth + weight_length + weight_similar);
        } else {
            // x
            tripletList.emplace_back(i, i - 2, weight_smooth);
            tripletList.emplace_back(i, i - 1, -4.0 * weight_smooth - weight_length);
            tripletList.emplace_back(i, i, 6.0 * weight_smooth + 2.0 * weight_length + weight_similar);
            tripletList.emplace_back(i, i + 1, -4.0 * weight_smooth - weight_length);
            tripletList.emplace_back(i, i + 2, weight_smooth);
            // y
            tripletList.emplace_back(i + n, i + n - 2, weight_smooth);
            tripletList.emplace_back(i + n, i + n - 1, -4.0 * weight_smooth - weight_length);
            tripletList.emplace_back(i + n, i + n, 6.0 * weight_smooth + 2.0 * weight_length + weight_similar);
            tripletList.emplace_back(i + n, i + n + 1, -4.0 * weight_smooth - weight_length);
            tripletList.emplace_back(i + n, i + n + 2, weight_smooth);
        }
    }


    solver->data()->setNumberOfVariables(numOfVars);
    solver->data()->setNumberOfConstraints(numOfCons);

    // TODO 这里如果直接填nnz更好，避免多次的内存分配
    // sm1.reserve(nnz);     // Allocate room for nnz nonzeros elements.
    hessian.resize(numOfVars, numOfVars);
    // 将 Triplet 列表设置到稀疏矩阵中
    hessian.setFromTriplets(tripletList.begin(), tripletList.end());

    gradient.resize(numOfVars);
    gradient = -weight_similar * ref_xy.array();

    linearMatrix.resize(numOfCons, numOfVars);
    for (int i = 0; i < numOfVars; ++i) {
        linearMatrix.coeffRef(i, i) = 1.0;
    }

    lowerBound.resize(numOfCons);
    upperBound.resize(numOfCons);
    lowerBound = ref_xy.array() - limit_buffer;
    upperBound = ref_xy.array() + limit_buffer;


    if (!solver->data()->setHessianMatrix(hessian)) return false;
    if (!solver->data()->setGradient(gradient)) return false;
    if (!solver->data()->setLinearConstraintsMatrix(linearMatrix)) return false;
    if (!solver->data()->setLowerBound(lowerBound)) return false;
    if (!solver->data()->setUpperBound(upperBound)) return false;

    // std::cout << "hessian" <<hessian<< std::endl;
    // std::cout << "gradient" <<gradient<< std::endl;
    // std::cout << "linearMatrix" <<linearMatrix<< std::endl;
    // std::cout << "lowerBound" <<lowerBound<< std::endl;
    // std::cout << "upperBound" <<upperBound<< std::endl;

    return true;
}

int main() {
    rapidcsv::Document doc("../data.csv", rapidcsv::LabelParams(0, -1));

    std::vector<double> utm_x = doc.GetColumn<double>("x");
    std::vector<double> utm_y = doc.GetColumn<double>("y");

    // utm_x.resize(10);
    // utm_y.resize(10);


    int point_num = utm_x.size();
    std::cout << "read file with point num " << utm_x.size() << std::endl;

    Eigen::Map<Eigen::VectorXd> x(utm_x.data(), utm_x.size());
    Eigen::Map<Eigen::VectorXd> y(utm_y.data(), utm_y.size());

    double x_min_value = x.minCoeff();
    double y_min_value = y.minCoeff();
    x = x.array() - x_min_value;
    y = y.array() - y_min_value;
    double x_max_value = x.maxCoeff();
    double y_max_value = y.maxCoeff();

    Eigen::VectorXd ref_xy(x.size() + x.size());
    ref_xy << x, y;

    // std::cout<< x_min_value<<"  "<< x_max_value<<"  " << y_min_value<<"  " << y_max_value << std::endl;
    // std::cout<<ref_xy<<std::endl;

    // smooth
    std::cout << "init qp solver" << std::endl;
    OsqpEigen::Solver *solver = new OsqpEigen::Solver();

    // set the solver
    solver->settings()->setWarmStart(true);
    solver->settings()->setVerbosity(false);

    auto initialed = initMat(solver, point_num, ref_xy);
    std::cout << "initmat results:" << initialed << std::endl;
    // solve
    auto flag = solver->initSolver();

    if (!flag) {
        std::cout << "initilize QP solver failed" << std::endl;
    } else {
        std::cout << "initilize QP solver successed" << std::endl;
    }

    auto error_flag = solver->solveProblem();

    Eigen::VectorXd QPSolution = solver->getSolution();
    // std::cout << std::fixed << std::setprecision(3);
    // std::cout << QPSolution<< std::endl;

    Eigen::VectorXd x_ = QPSolution.segment(0, point_num);
    Eigen::VectorXd y_ = QPSolution.segment(point_num, point_num);

    std::vector<double> x_opt(x_.data(), x_.data() + x_.size());
    std::vector<double> y_opt(y_.data(), y_.data() + y_.size());
    std::vector<double> x_raw(x.data(), x.data() + x.size());
    std::vector<double> y_raw(y.data(), y.data() + y.size());


    // Set the size of output image to 1200x780 pixels
    plt::figure_size(1200, 780);
    // Plot line from given x and y data. Color is selected automatically.
    plt::plot(x_opt, y_opt);
    plt::plot(x_raw, y_raw, "r--");

    // Add graph title
    plt::title("Sample figure");
    // Save the image (file format is determined by the extension)
    // plt::save("basic.png");
    plt::axis("equal");
    plt::show();
    plt::detail::_interpreter::kill();
}
