#include <iostream>
#include <vector>
#include <cmath>
#include <ceres/ceres.h>
#include <ceres/rotation.h>
#include <Eigen/Dense>

using namespace std;
using namespace Eigen;

// 定义控制点数据类型
struct ControlPoint {
    double x;
    double y;
};

// 定义曲率约束残差
struct CurvatureConstraint {
    CurvatureConstraint(double x1, double y1, double x2, double y2, double x3, double y3, double max_curvature)
        : x1(x1), y1(y1), x2(x2), y2(y2), x3(x3), y3(y3), max_curvature(max_curvature) {}

    template <typename T>
    bool operator()(const T* const p1, const T* const p2, const T* const p3, T* residual) const {
        T dx1 = p2[0] - p1[0];
        T dy1 = p2[1] - p1[1];
        T dx2 = p3[0] - p2[0];
        T dy2 = p3[1] - p2[1];

        T cross_product = dx1 * dy2 - dy1 * dx2;
        T norm1 = sqrt(dx1 * dx1 + dy1 * dy1);
        T norm2 = sqrt(dx2 * dx2 + dy2 * dy2);
        T curvature = cross_product / (norm1 * norm2 * norm2);

        residual[0] = curvature - T(max_curvature);
        return true;
    }

    double x1, y1, x2, y2, x3, y3;
    double max_curvature;
};

int main() {
    // 初始化控制点
    vector<ControlPoint> control_points = {
        {0, 0}, {1, 2}, {3, 3}, {4, 2}, {5, 0}
    };

    // 初始化优化问题
    ceres::Problem problem;

    // 设置曲率约束
    double max_curvature = 0.1;
    for (size_t i = 1; i < control_points.size() - 1; ++i) {
        problem.AddResidualBlock(
            new ceres::AutoDiffCostFunction<CurvatureConstraint, 1, 2, 2, 2>(
                new CurvatureConstraint(
                    control_points[i - 1].x, control_points[i - 1].y,
                    control_points[i].x, control_points[i].y,
                    control_points[i + 1].x, control_points[i + 1].y,
                    max_curvature)),
            nullptr,
            &control_points[i - 1].x, &control_points[i].x, &control_points[i + 1].x
        );
    }

    // 配置求解器 
    ceres::Solver::Options options;
    options.linear_solver_type = ceres::DENSE_QR;
    options.minimizer_progress_to_stdout = false;

    ceres::Solver::Summary summary;
    ceres::Solve(options, &problem, &summary);

    // std::cout << summary.FullReport() << "\n";

    // 输出优化后的控制点
    for (const auto& point : control_points) {
        std::cout << "Point: (" << point.x << ", " << point.y << ")\n";
    }

    return 0;
}
