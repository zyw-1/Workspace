#include <iostream>
#include <vector>
#include <cmath>
#include <Eigen/Dense>
#include <unsupported/Eigen/Splines>

using namespace Eigen;
using namespace std;

// 样条插值的控制点
vector<Vector2d> controlPoints = {
    {0, 0}, {1, 2}, {3, 3}, {4, 2}, {5, 0}
};

// 计算样条路径
Spline2d computeSpline(const vector<Vector2d>& points) {
    MatrixXd controlMatrix(2, points.size());
    for (size_t i = 0; i < points.size(); ++i) {
        controlMatrix(0, i) = points[i].x();
        controlMatrix(1, i) = points[i].y();
    }
    Spline2d spline = SplineFitting<Spline2d>::Interpolate(controlMatrix, 3);
    return spline;
}

// 计算曲率
double computeCurvature(const Spline2d& spline, double t) {
    Vector2d firstDerivative = spline.derivatives(t, 1);
    Vector2d secondDerivative = spline.derivatives(t, 2);
    double numerator = abs(firstDerivative(0) * secondDerivative(1) - firstDerivative(1) * secondDerivative(0));
    double denominator = pow(firstDerivative.norm(), 3);
    return numerator / denominator;
}

// 计算速度
double computeSpeed(double curvature) {
    double maxSpeed = 10; // 最大速度
    double maxAcceleration = 2; // 最大加速度
    return min(maxSpeed, sqrt(maxAcceleration / curvature));
}

int main() {
    Spline2d spline = computeSpline(controlPoints);

    // 输出路径点及其曲率和速度
    for (double t = 0; t <= 1; t += 0.01) {
        auto point = spline(t);
        double curvature = computeCurvature(spline, t);
        double speed = computeSpeed(curvature);
        cout << "Point: (" << point(0) << ", " << point(1) << "), Curvature: " << curvature << ", Speed: " << speed << endl;
    }

    return 0;
}
