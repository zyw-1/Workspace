// example.cpp
#include <iostream>
#include <string>

class MyClass {
public:
    MyClass(const std::string& name) : name(name) {}
    void greet() const {
        std::cout << "Hello, " << name << std::endl;
    }
private:
    std::string name;
};

MyClass global_object("World");

extern "C" {
    void greet_global_object() {
        global_object.greet();
    }
}
