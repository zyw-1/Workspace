import ctypes

# 加载共享库
lib = ctypes.CDLL('./libexample.so')

# 调用函数来使用全局对象
lib.greet_global_object()  # 输出：Hello, World
