//
// Created by faye on 7/7/24.
//
#define SPDLOG_ACTIVE_LEVEL SPDLOG_LEVEL_TRACE
#include <spdlog/spdlog.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <spdlog/sinks/stdout_color_sinks.h>
#include <memory>
#include <iostream>
int main() {
    try {
        // 创建控制台日志器（带颜色）
        auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
        console_sink->set_level(spdlog::level::trace); // 设置日志级别
        console_sink->set_pattern("[%H:%M:%S][%n][thr %t][%s:%!():%#] %v");

        // 创建文件日志器
        auto file_sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>("logs/my_log.txt", true);
        file_sink->set_level(spdlog::level::trace); // 设置日志级别
        file_sink->set_pattern("[%H:%M:%S][%n][thr %t][%s:%!():%#] %v");

        // 创建一个多重日志器，包含控制台和文件日志器
        spdlog::logger logger("multi_sink", {console_sink, file_sink});
        logger.set_level(spdlog::level::trace); // 设置多重日志器的日志级别

        // 设置全局日志器（可选）
        spdlog::set_default_logger(std::make_shared<spdlog::logger>(logger));

        // 输出日志
        logger.debug("This is a debug message");
        logger.info("This is an info message");
        logger.warn("This is a warning message");
        logger.error("This is an error message");

    } catch (const spdlog::spdlog_ex &ex) {
        std::cerr << "Log initialization failed: " << ex.what() << std::endl;
        return 1;
    }

    return 0;
}
