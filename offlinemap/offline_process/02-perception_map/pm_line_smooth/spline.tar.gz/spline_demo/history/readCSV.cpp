#include <iostream>
#include <vector>
#include "rapidcsv.h"
#include <filesystem>
#include <Eigen/Dense>
#include "matplotlibcpp.h"

namespace plt = matplotlibcpp;
namespace fs = std::filesystem;

fs::path cwd = fs::current_path();
fs::path csv_path = "data.csv";

int main()
{
    rapidcsv::Document doc("../data.csv", rapidcsv::LabelParams(0, -1));

    std::vector<double> col = doc.GetColumn<double>("x");
    std::cout << "Read " << col.size() << " values." << std::endl;

    Eigen::Map<Eigen::VectorXd> eigen_vector(col.data(), col.size()); // 将 std::vector 映射到 Eigen 数组
    std::cout << "Eigen Vector: " <<std::fixed<< eigen_vector << std::endl;

    // 修改原始的 std::vector 数据
    col[0] = 10.0;

    // 输出修改后的 Eigen 数组
    std::cout << "Eigen Vector (after modification): " <<std::fixed<< eigen_vector<< std::endl;

    plt::plot({1,3,2,4});
    plt::show();
}
